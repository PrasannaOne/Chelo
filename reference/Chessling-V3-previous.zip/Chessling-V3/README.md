# Chessling V3 · Raise a chess monster

Chessling is an offline-first chess pet. It starts at 100 provisional Growth Elo, keeps an individual learning brain, remembers opening habits and positions, and changes its preferences through play. The long-term game is pet-versus-pet: people raise creatures; the creatures compete.

## Run it

Serve this folder over HTTP so the Web Worker and Service Worker work reliably:

```bash
python -m http.server 8000
```

Open `http://localhost:8000`.

## What's new in V3

- **Visible Practice Mode:** your Chessling plays both colours on the actual board, move by move. It pauses between moves, can be paused/resumed/stopped, and automatically pauses when the page is hidden. It never runs a hidden match in the background.
- **No self-play rating farming:** practice sessions are tracked separately. They do not change Growth Elo, Arena Elo, wins, losses or draws.
- **Premium convenience, not premium intelligence:** the UI reserves a locked “Skip to end · Pro” option. Fast-forward is not active until real Pro entitlements are implemented. Watching practice stays free.
- **Same search budget for every pet:** Growth Elo no longer unlocks deeper search. Individuality comes from the pet's own memories, opening habits, learned positional preferences and material genes.
- **Neutral learned positional preferences:** centre, pawn advance, development and king-shelter weights start at zero. They are adjusted from the consequences of the pet's own moves.
- **Compact brain storage:** local saves and Soul exports use abbreviated compact JSON. The hard cap is measured against the actual compact UTF-8 brain representation: 51,200 bytes. The original separate 1,000-position ceiling remains; this is not a limit on games played.
- **Backward compatibility:** V2 Souls can still be imported; new exports use compact V3 encoding.
- **V3 Arena foundation:** an optional Cloudflare Worker/D1 API is included for globally unique trainer/pet handles, owner-only brain sync, public pet profiles and legal match replay. Challenges remain unranked until target-side AI moves can be independently attested.

## What's included

- `index.html`, `style.css`, `app.js` — mobile-friendly local experience and visible self-play.
- `chess.js` — dependency-free chess rules engine.
- `brain.js` — opening mirroring, FEN trap memory, evolving material genes, neutral learned positional weights, compact saves and the 50 KiB hard cap.
- `ai-worker.js` — off-main-thread search.
- `pieces.svg` — consistent vector chess pieces.
- `sw.js`, `manifest.json`, `icon.svg` — PWA and offline shell.
- `arena/worker.mjs`, `arena/schema.sql`, `arena/wrangler.toml` — optional Cloudflare Arena foundation.
- `tests/` and `arena/worker.test.mjs` — chess, search, learning, storage, UI, PWA and Arena helper checks.
- `CHESSLING_MASTER_SPEC.md` — product decisions and architecture.
- `reference/` — original Gemini/Pawnling ZIP and original blueprint, preserved unchanged.

## Core rules and data model

- Human-vs-pet games are played by the player as White and Chessling as Black.
- Practice Mode is the same pet on both sides. It is rehearsal only, never a ranked result.
- The pet starts at 100 Growth Elo. This is a provisional local progression indicator, not a calibrated playing-strength rating.
- Arena Elo is separate and is not currently active.
- The compact pet brain is at most 50 KiB (51,200 bytes). Current-game history is stored separately from the brain.
- Soul export/import preserves the pet's identity, brain, memories, traits, stats and optional active game. A Soul cannot set a public Arena rating.
- Undo in a human match restores the brain snapshot from before that turn.

## Honest limitations

Chessling is a compact adaptive heuristic/search prototype, not a neural network or a proven high-strength chess engine. A visible rating increase or more games played is not evidence of stronger chess. The positional policy now learns from individual move consequences, but its effect still needs controlled held-out benchmarks.

The Arena Worker is not connected to the local interface. It does not yet provide token recovery, moderation, rate limiting, payments or Pro entitlement checks. Most importantly, its current challenge route checks that a submitted match is legal but cannot prove the target pet itself generated its moves. It therefore records challenges as unranked and does not change Arena Elo. The intended anti-farming rule is at most three ranked matches per challenger trainer against a given pet per UTC day; self-play never earns rating at all. Do not enable ranked results until move attestation is genuinely verified.

## Tests

With Node.js installed, run:

```bash
node tests/smoke.test.js
node tests/worker.test.js
node arena/worker.test.mjs
```

The smoke suite checks standard perft positions, special moves, draw rules, opening mirroring, FEN-memory influence, continuous feedback, compact Soul portability, 50 KiB enforcement, neutral learned policy, practice no-rating behaviour, mate-in-one, the square board and PWA assets.

## Cloudflare Arena foundation

See [`arena/README.md`](arena/README.md). The static app works without the Worker. GitHub is the source repository; Cloudflare Pages is the intended commercial static host.

## Original project input

The complete Gemini-generated Pawnling starter and its blueprint remain under `reference/`. The original ZIP was not overwritten.
