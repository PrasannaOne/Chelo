# Chessling learning validation plan

The current three-layer brain is a compact adaptive prototype. Before describing Chessling as an AI that measurably becomes stronger, validate it against a frozen baseline.

## Test design

1. Create a fixed, versioned set of legal positions and short opening sequences. Keep a private held-out subset that is never used to train the pet.
2. For each test, save a fresh baseline Soul at the same starting brain state and a second Soul that has received the defined training games.
3. Use identical search time, node limits, opening positions and colour assignments for both versions.
4. Alternate colours and run enough games to reduce random-seed noise.
5. Record results separately for each layer: opening habits on/off, FEN memory on/off, genetic weights on/off, then all layers together.
6. Measure win/draw/loss rate, blunders, material loss, missed mate/tactic opportunities, opening-repertoire reproduction and search cost. Do not use the displayed Growth Elo as the measurement result.
7. Retest after memory pruning and Soul export/import to confirm that a compact or transferred brain retains its measured behaviour.

## Minimum evidence before a public learning claim

- The trained brain should outperform its own frozen baseline on held-out positions or match sets under the same compute budget.
- The measured improvement should repeat over multiple seeds and colour assignments.
- The test must detect regressions too: if a layer makes play worse, tune it or disable it rather than disguising the result with an Elo label.
- Results must be reported honestly with sample size, opponent, time/node budget and uncertainty.

## Current status

The smoke suite currently verifies that the three layers are wired into the game loop, that opening mirroring can affect a legal reply, that a remembered move can influence a familiar position, and that outcome signals move in the intended directions. It does **not** yet establish a statistically reliable increase in playing strength. A proper repeated-game/held-out benchmark is the next major AI milestone.
