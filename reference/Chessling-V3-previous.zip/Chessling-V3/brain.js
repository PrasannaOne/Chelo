/*
 * Chessling's local 3-layer learning brain.
 * Layer 1: opening habit memory (learns the player's repertoire and Chessling's replies).
 * Layer 2: FEN trap memory (position/move values reinforced by match outcomes).
 * Layer 3: adaptive material genes (near-equal hatchling values mature and receive outcome feedback).
 *
 * The 50 KiB limit is enforced against the complete serialized pet brain, not a guessed position count.
 */
(() => {
  'use strict';
  const LIMIT = 50 * 1024;
  const MAX_POSITIONS = 1000;
  const START_WEIGHTS = { p:100, n:110, b:110, r:120, q:130, k:9000 };
  const TYPES = ['p','n','b','r','q'];
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const now = () => Date.now();
  const encoder = () => new TextEncoder();
  const byteLength = value => encoder().encode(JSON.stringify(value)).length;
  const fenKey = fen => String(fen).trim().split(/\s+/).slice(0, 4).join(' ');
  const mirrorUci = move => {
    if (typeof move !== 'string' || !/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)) return '';
    const flipRank = square => square[0] + (9 - Number(square[1]));
    return flipRank(move.slice(0,2)) + flipRank(move.slice(2,4)) + (move[4] || '');
  };
  const hash32 = text => {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  };

  class ChesslingBrain {
    constructor(storageKey = 'chessling_pet_1', options = {}) {
      this.storageKey = storageKey;
      this.persist = options.persist !== false;
      this.data = options.data ? this.normalise(options.data) : this.load();
      this.lastSearch = null;
    }

    defaults() {
      const stamp = now();
      return {
        schema:3, petName:'Chessling', handle:'', trainerName:'', gen:1,
        elo:100, trainerReferenceElo:1000,
        wins:0, losses:0, draws:0, games:0, practiceGames:0,
        weights:{...START_WEIGHTS},
        policy:{center:0,advance:0,development:0,shelter:0},
        traits:{bold:50,curious:50,patient:50},
        memory:{}, humanOpenings:{}, openingReplies:{}, pending:[],
        geneticTrace:{p:0,n:0,b:0,r:0,q:0},
        lastHumanMove:null, createdAt:stamp, updatedAt:stamp
      };
    }

    normalise(source) {
      const base = this.defaults();
      const old = source && typeof source === 'object' ? source : {};
      const data = {...base, ...old, schema:3};
      data.weights = {...START_WEIGHTS, ...(old.weights || {})};
      data.policy = {...base.policy, ...(old.policy || {})};
      data.traits = {...base.traits, ...(old.traits || {})};
      for (const key of Object.keys(data.weights)) data.weights[key] = clamp(Number(data.weights[key]) || START_WEIGHTS[key], 1, 2000);
      for (const key of Object.keys(data.policy)) data.policy[key] = clamp(Number(data.policy[key]) || 0, -250, 250);
      for (const key of Object.keys(data.traits)) { const value=Number(data.traits[key]); data.traits[key]=clamp(Number.isFinite(value)?value:50,0,100); }
      data.memory = old.memory && typeof old.memory === 'object' ? old.memory : {};
      data.humanOpenings = old.humanOpenings && typeof old.humanOpenings === 'object' ? old.humanOpenings : {};
      data.openingReplies = old.openingReplies && typeof old.openingReplies === 'object' ? old.openingReplies : {};
      data.pending = Array.isArray(old.pending) ? old.pending : [];
      data.geneticTrace = {...base.geneticTrace, ...(old.geneticTrace || {})};
      data.elo = Math.max(100, Number.isFinite(Number(data.elo)) ? Math.round(Number(data.elo)) : 100);
      for (const field of ['wins','losses','draws','games','practiceGames','gen']) data[field] = Math.max(0, Math.floor(Number(data[field]) || (field === 'gen' ? 1 : 0)));
      return data;
    }

    load() {
      if (!this.persist) return this.defaults();
      try {
        const raw = localStorage.getItem(this.storageKey);
        if (!raw) return this.defaults();
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') return this.defaults();
        const data = this.normalise(this.expandData(parsed));
        return data;
      } catch (error) {
        console.warn('Chessling started a fresh brain because its save could not be read.', error);
        return this.defaults();
      }
    }

    compactData(data = this.data) {
      const types = ['p','n','b','r','q','k'];
      const policyKeys = ['center','advance','development','shelter'];
      const packMap = (source, kind) => Object.entries(source || {}).map(([fen, moves]) => [fen,
        Object.entries(moves || {}).map(([move, value]) => kind === 'memory'
          ? [move, Number(value.score)||0, Number(value.visits)||0, Number(value.mirror)||0, Number(value.outcomes)||0, Number(value.last)||0]
          : kind === 'opening'
            ? [move, Number(value.count)||0, Number(value.last)||0]
            : [move, Number(value.count)||0, Number(value.score)||0, Number(value.last)||0])
      ]);
      return {
        v:3,
        i:[data.petName,data.handle,data.trainerName,data.gen,data.elo,data.trainerReferenceElo,data.wins,data.losses,data.draws,data.games,data.practiceGames],
        w:types.map(key=>Number(data.weights?.[key])||0),
        a:policyKeys.map(key=>Number(data.policy?.[key])||0),
        t:['bold','curious','patient'].map(key=>Number(data.traits?.[key])||0),
        m:packMap(data.memory,'memory'),
        h:packMap(data.humanOpenings,'opening'),
        o:packMap(data.openingReplies,'reply'),
        q:(data.pending||[]).map(item=>[item.f,item.m,item.p,item.e,item.b,
          policyKeys.map(key=>Number(item.d?.[key])||0),item.r,item.ply,item.side,item.at]),
        g:types.slice(0,5).map(key=>Number(data.geneticTrace?.[key])||0),
        l:data.lastHumanMove?[data.lastHumanMove.fen,data.lastHumanMove.move,data.lastHumanMove.mirror,data.lastHumanMove.ply,data.lastHumanMove.at]:null,
        c:Number(data.createdAt)||0,u:Number(data.updatedAt)||0
      };
    }

    expandData(source) {
      if (!source || source.v !== 3 || !Array.isArray(source.i)) return source;
      const types = ['p','n','b','r','q','k'];
      const policyKeys = ['center','advance','development','shelter'];
      const i=source.i;
      const unpackMap=(rows,kind)=>Object.fromEntries((Array.isArray(rows)?rows:[]).map(row=>{
        const fen=row?.[0], entries=Array.isArray(row?.[1])?row[1]:[];
        const values=Object.fromEntries(entries.map(item=>kind==='memory'
          ? [item[0],{score:item[1],visits:item[2],mirror:item[3],outcomes:item[4],last:item[5]}]
          : kind==='opening'
            ? [item[0],{count:item[1],last:item[2]}]
            : [item[0],{count:item[1],score:item[2],last:item[3]}]));
        return [fen,values];
      }));
      return {
        schema:3,petName:i[0]||'Chessling',handle:i[1]||'',trainerName:i[2]||'',gen:i[3]||1,
        elo:i[4]||100,trainerReferenceElo:i[5]||1000,wins:i[6]||0,losses:i[7]||0,draws:i[8]||0,
        games:i[9]||0,practiceGames:i[10]||0,
        weights:Object.fromEntries(types.map((key,index)=>[key,source.w?.[index]])),
        policy:Object.fromEntries(policyKeys.map((key,index)=>[key,source.a?.[index]])),
        traits:{bold:source.t?.[0],curious:source.t?.[1],patient:source.t?.[2]},
        memory:unpackMap(source.m,'memory'),humanOpenings:unpackMap(source.h,'opening'),
        openingReplies:unpackMap(source.o,'reply'),
        pending:(Array.isArray(source.q)?source.q:[]).map(item=>({
          f:item[0],m:item[1],p:item[2],e:item[3],b:item[4],
          d:Object.fromEntries(policyKeys.map((key,index)=>[key,item[5]?.[index]||0])),
          r:item[6],ply:item[7],side:item[8],at:item[9]
        })),
        geneticTrace:Object.fromEntries(types.slice(0,5).map((key,index)=>[key,source.g?.[index]||0])),
        lastHumanMove:source.l?{fen:source.l[0],move:source.l[1],mirror:source.l[2],ply:source.l[3],at:source.l[4]}:null,
        createdAt:source.c||now(),updatedAt:source.u||now()
      };
    }

    size() { return byteLength(this.compactData()); }
    memoryCount() { return Object.keys(this.data.memory).length; }

    pruneToBudget() {
      const memoryKeys = () => Object.keys(this.data.memory).sort((a, b) => {
        const aLast = Math.max(0, ...Object.values(this.data.memory[a] || {}).map(v => Number(v.last) || 0));
        const bLast = Math.max(0, ...Object.values(this.data.memory[b] || {}).map(v => Number(v.last) || 0));
        return aLast - bLast;
      });
      while (this.memoryCount() > MAX_POSITIONS || this.size() > LIMIT - 128) {
        const key = memoryKeys()[0];
        if (!key) break;
        delete this.data.memory[key];
      }

      const pruneOldest = object => {
        // Opening maps are nested by FEN -> move -> {count,last}; measure the newest
        // child timestamp so pruning is genuinely least-recently-used at FEN level.
        const latestUse = value => {
          let latest = Number(value?.last) || 0;
          if (value && typeof value === 'object') {
            for (const child of Object.values(value)) latest = Math.max(latest, Number(child?.last) || 0);
          }
          return latest;
        };
        const keys = Object.keys(object).sort((a, b) => latestUse(object[a]) - latestUse(object[b]));
        while (keys.length && this.size() > LIMIT - 128) delete object[keys.shift()];
      };
      pruneOldest(this.data.humanOpenings);
      pruneOldest(this.data.openingReplies);

      // The current game is valuable, but an abandoned or exceptionally long game cannot consume the whole brain.
      while (this.data.pending.length > 160 || this.size() > LIMIT - 128) {
        if (!this.data.pending.length) break;
        this.data.pending.shift();
      }

      if (this.size() > LIMIT) {
        // Last-resort compaction removes optional historical memory, never identity or learned genes.
        this.data.memory = {};
        this.data.humanOpenings = {};
        this.data.openingReplies = {};
        while (this.data.pending.length && this.size() > LIMIT) this.data.pending.shift();
      }
      if (this.size() > LIMIT) throw new Error('Chessling core data exceeds the 50 KiB storage budget.');
    }

    save() {
      this.data.updatedAt = now();
      this.pruneToBudget();
      if (!this.persist) return true;
      try {
        localStorage.setItem(this.storageKey, JSON.stringify(this.compactData()));
        return true;
      } catch (error) {
        // Retry after aggressively removing old position memories.
        try {
          this.data.memory = {};
          this.pruneToBudget();
          localStorage.setItem(this.storageKey, JSON.stringify(this.compactData()));
          return true;
        } catch (secondError) {
          console.error('Chessling could not save its brain.', secondError);
          return false;
        }
      }
    }

    simplifyFen(fen) { return fenKey(fen); }

    entry(fen, move) {
      const key = this.simplifyFen(fen);
      this.data.memory[key] ||= {};
      this.data.memory[key][move] ||= {score:0, visits:0, mirror:0, outcomes:0, last:now()};
      const entry = this.data.memory[key][move];
      entry.last = now();
      return entry;
    }

    observeHumanMove(fen, move, ply = 0) {
      const key = this.simplifyFen(fen);
      // Layer 1 deliberately records only the first six full moves as opening repertoire.
      if (ply <= 12) {
        this.data.humanOpenings[key] ||= {};
        const opening = this.data.humanOpenings[key][move] || {count:0, last:0};
        opening.count++;
        opening.last = now();
        this.data.humanOpenings[key][move] = opening;
      }
      this.data.lastHumanMove = {fen:key, move, mirror:mirrorUci(move), ply, at:now()};
      this.save();
    }

    recordGeneticPosition(chess, side = 'b') {
      if (!chess) return;
      const counts = {p:0,n:0,b:0,r:0,q:0};
      for (const row of chess.board()) for (const piece of row) {
        if (piece && piece.color === side && counts[piece.type] !== undefined) counts[piece.type]++;
      }
      for (const p of TYPES) this.data.geneticTrace[p] = this.data.geneticTrace[p] * 0.94 + counts[p] * 0.06;
    }

    positionFeatures(chess, perspective = chess.turn()) {
      const board = chess.board();
      const features = {center:0,advance:0,development:0,shelter:0};
      const sign = color => color === perspective ? 1 : -1;
      const homeSquares = {
        w:{n:['b1','g1'],b:['c1','f1'],r:['a1','h1'],q:['d1']},
        b:{n:['b8','g8'],b:['c8','f8'],r:['a8','h8'],q:['d8']}
      };
      const fileName = 'abcdefgh';
      let kings = {};
      for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
        const piece = board[r][c];
        if (!piece) continue;
        const color = piece.color, weight = sign(color), type = piece.type;
        const square = fileName[c] + (8-r);
        if (type === 'k') { kings[color] = {r,c}; continue; }
        const centerX = Math.max(0, 1 - Math.abs(3.5-c)/3.5);
        const centerY = Math.max(0, 1 - Math.abs(3.5-r)/3.5);
        const centerValue = (centerX + centerY) / 2;
        const centerFactor = type === 'n' ? 1.35 : type === 'b' ? 1.1 : type === 'p' ? 0.65 : 0.35;
        features.center += weight * centerValue * centerFactor;
        if (type === 'p') {
          const progress = color === 'w' ? 6-r : r-1;
          features.advance += weight * Math.max(0, progress) / 6;
        }
        if (['n','b','r','q'].includes(type) && !homeSquares[color][type].includes(square)) {
          features.development += weight * (type === 'n' || type === 'b' ? 1 : 0.35);
        }
      }
      for (const color of ['w','b']) {
        const king = kings[color];
        if (!king) continue;
        const direction = color === 'w' ? -1 : 1;
        let shield = 0;
        for (const fileOffset of [-1,0,1]) {
          const file = king.c + fileOffset;
          const rank = king.r + direction;
          if (file < 0 || file > 7 || rank < 0 || rank > 7) continue;
          const pawn = board[rank][file];
          if (pawn && pawn.type === 'p' && pawn.color === color) shield++;
        }
        features.shelter += sign(color) * shield;
      }
      return features;
    }

    evaluate(chess, perspective = chess.turn()) {
      const board = chess.board();
      const weights = this.data.weights;
      let total = 0;
      for (let r=0;r<8;r++) for (let c=0;c<8;c++) {
        const piece = board[r][c];
        if (!piece) continue;
        const sign = piece.color === perspective ? 1 : -1;
        total += sign * (weights[piece.type] || 100);
      }
      // The shared search knows the legal rules. Positional preferences start neutral and
      // are learned by this individual pet instead of being baked into its starting brain.
      const features = this.positionFeatures(chess, perspective);
      for (const key of Object.keys(this.data.policy)) total += (this.data.policy[key] || 0) * (features[key] || 0);
      if (chess.inCheck(perspective)) total -= 45;
      if (chess.inCheck(perspective === 'w' ? 'b' : 'w')) total += 45;
      return total;
    }

    observePetMove(fen, move, meta = {}, ply = 0, chessAfter = null) {
      const key = this.simplifyFen(fen);
      const side = meta.side === 'w' ? 'w' : 'b';
      const entry = this.entry(key, move);
      entry.visits++;
      const isNewPosition = entry.visits === 1;
      const piece = meta.piece || 'p';
      if (meta.captured) this.data.traits.bold = clamp(this.data.traits.bold + 1.1, 0, 100);
      if (isNewPosition) this.data.traits.curious = clamp(this.data.traits.curious + 0.7, 0, 100);
      if (!meta.captured && !meta.gaveCheck) this.data.traits.patient = clamp(this.data.traits.patient + 0.35, 0, 100);

      let before = null, after = null, beforeEval = 0, afterEval = 0;
      try {
        const Core = typeof window !== 'undefined' ? window.ChessCore : globalThis.ChessCore;
        if (Core && chessAfter) {
          before = new Core(fen);
          after = this.positionFeatures(chessAfter, side);
          const oldFeatures = this.positionFeatures(before, side);
          const delta = {};
          for (const name of Object.keys(oldFeatures)) delta[name] = Number((after[name] - oldFeatures[name]).toFixed(3));
          beforeEval = this.evaluate(before, side);
          afterEval = this.evaluate(chessAfter, side);
          this.data.pending.push({f:key,m:move,p:piece,e:Math.round(afterEval),b:Math.round(beforeEval),d:delta,r:0,ply,side,at:now()});
        } else {
          this.data.pending.push({f:key,m:move,p:piece,e:0,b:0,d:{},r:0,ply,side,at:now()});
        }
      } catch {
        this.data.pending.push({f:key,m:move,p:piece,e:Math.round(afterEval),b:Math.round(beforeEval),d:{},r:0,ply,side,at:now()});
      }

      // Retain the original opening-reply layer, now from either colour in practice games.
      if (ply <= 12 && chessAfter) {
        this.data.openingReplies[key] ||= {};
        const reply = this.data.openingReplies[key][move] || {count:0,score:0,last:0};
        reply.count++;
        reply.last = now();
        this.data.openingReplies[key][move] = reply;
      }
      this.recordGeneticPosition(chessAfter, side);
      this.save();
    }

    resolveLastPetMove(chess) {
      let item = null;
      for (let i=this.data.pending.length-1;i>=0;i--) {
        if (!this.data.pending[i].r) { item = this.data.pending[i]; break; }
      }
      if (!item) return;
      const perspective = item.side === 'w' ? 'w' : 'b';
      const replyEval = this.evaluate(chess, perspective);
      const swing = replyEval - item.e;
      const totalSignal = clamp((replyEval - item.b) / 160, -1, 1);
      const entry = this.entry(item.f, item.m);
      if (swing < -35) entry.score = clamp(entry.score + Math.max(-10, swing / 22), -100, 100);
      else if (swing > 55) entry.score = clamp(entry.score + Math.min(4, swing / 45), -100, 100);
      for (const [name, change] of Object.entries(item.d || {})) {
        this.data.policy[name] = clamp((this.data.policy[name] || 0) + Number(change || 0) * totalSignal * 1.6, -250, 250);
      }
      item.r = 1;
      this.save();
    }

    generation() {
      const g = this.data.gen;
      if (g < 2) return 'Hatchling';
      if (g < 4) return 'Apprentice Tactician';
      if (g < 8) return 'Trap Hunter';
      if (g < 15) return 'Veteran Strategist';
      return 'Chess Monster';
    }

    personality() {
      const traits = this.data.traits;
      const ranked = Object.entries(traits).sort((a,b) => b[1] - a[1]);
      if (ranked[0][1] - ranked[1][1] < 5) return 'Still finding its style';
      return ranked[0][0] === 'bold' ? 'Bold and tactical' : ranked[0][0] === 'curious' ? 'Curious explorer' : 'Patient planner';
    }

    orderMoves(chess, moves, ttMove = null) {
      const values = {p:100,n:320,b:330,r:500,q:900,k:20000};
      return moves.sort((a,b) => {
        const score = move => {
          let value = 0;
          if (ttMove && move.uci === ttMove) value += 100000;
          if (move.captured) value += 10000 + values[move.captured] * 10 - values[move.piece];
          if (move.promotion) value += 8000 + values[move.promotion];
          const key = this.simplifyFen(chess.fen());
          const remembered = this.data.memory[key]?.[move.uci];
          if (remembered) value += remembered.score * 4;
          return value;
        };
        return score(b) - score(a);
      });
    }

    chooseMove(chess, options = {}) {
      const legal = chess.moves({verbose:true,skipSan:true});
      if (!legal.length) return {move:null, depth:0, nodes:0, score:null};
      const start = now();
      const timeLimit = Math.max(80, Number(options.timeMs) || 450);
      const nodeLimit = Math.max(1000, Number(options.nodeLimit) || 35000);
      const maxDepth = 5; // Same search ceiling for every pet; Elo never unlocks thinking power.
      const memoryKey = this.simplifyFen(chess.fen());
      const remembered = this.data.memory[memoryKey] || {};
      const book = this.data.openingReplies[memoryKey] || {};
      const currentFullMove = Number(chess.fen().split(' ')[5]) || 1;
      const mirroredHabit = currentFullMove <= 6 ? this.data.lastHumanMove?.mirror : '';
      const mirroredHabitCount = this.data.lastHumanMove?.fen ? (this.data.humanOpenings[this.data.lastHumanMove.fen]?.[this.data.lastHumanMove.move]?.count || 0) : 0;
      const table = new Map();
      const MATE = 30000, INF = 32000;
      let nodes = 0;
      let stopped = false;
      const deadline = start + timeLimit;

      const terminal = (position, moves, ply) => {
        if (moves.length) return null;
        return position.inCheck() ? -MATE + ply : 0;
      };

      const evaluateForTurn = position => this.evaluate(position, position.turn());

      const quiescence = (position, alpha, beta, ply, qDepth) => {
        nodes++;
        if (nodes >= nodeLimit || now() >= deadline) { stopped = true; return evaluateForTurn(position); }
        const inCheck = position.inCheck();
        const all = position.moves({verbose:true,skipSan:true});
        const endScore = terminal(position, all, ply);
        if (endScore !== null) return endScore;
        const standPat = evaluateForTurn(position);
        if (!inCheck) {
          if (standPat >= beta) return beta;
          if (standPat > alpha) alpha = standPat;
          if (qDepth <= 0) return standPat;
        } else if (qDepth <= -6) {
          // Never stand pat while in check. At the emergency horizon, search every legal
          // evasion once and evaluate the resulting positions rather than accepting check.
          let evasionBest = -INF;
          for (const move of all) {
            position.move(move.uci, {skipSan:true});
            const score = -evaluateForTurn(position);
            position.undo();
            if (score > evasionBest) evasionBest = score;
          }
          return evasionBest;
        }
        const candidates = inCheck ? all : all.filter(m => m.captured || m.promotion);
        const ordered = this.orderMoves(position, candidates);
        let best = inCheck ? -INF : standPat;
        for (const move of ordered) {
          if (stopped) break;
          position.move(move.uci, {skipSan:true});
          const score = -quiescence(position, -beta, -alpha, ply + 1, qDepth - 1);
          position.undo();
          if (score > best) best = score;
          if (score > alpha) alpha = score;
          if (alpha >= beta) break;
        }
        return best;
      };

      const negamax = (position, depth, alpha, beta, ply) => {
        nodes++;
        if (nodes >= nodeLimit || now() >= deadline) { stopped = true; return evaluateForTurn(position); }
        const moves = position.moves({verbose:true,skipSan:true});
        const endScore = terminal(position, moves, ply);
        if (endScore !== null) return endScore;
        if (position.s.half >= 150 || position.positions.filter(k => k === position.positionKey()).length >= 5 || position.insufficient()) return 0;
        if (depth <= 0) return quiescence(position, alpha, beta, ply, 4);

        const key = position.positionKey() + `|${position.s.half}`;
        const cached = table.get(key);
        const alphaOriginal = alpha;
        if (cached && cached.depth >= depth) {
          if (cached.flag === 'exact') return cached.score;
          if (cached.flag === 'lower') alpha = Math.max(alpha, cached.score);
          else if (cached.flag === 'upper') beta = Math.min(beta, cached.score);
          if (alpha >= beta) return cached.score;
        }
        const ordered = this.orderMoves(position, moves, cached?.best || null);
        let best = -INF, bestMove = null;
        for (const move of ordered) {
          if (stopped) break;
          position.move(move.uci, {skipSan:true});
          const score = -negamax(position, depth - 1, -beta, -alpha, ply + 1);
          position.undo();
          if (score > best) { best = score; bestMove = move.uci; }
          if (score > alpha) alpha = score;
          if (alpha >= beta) break;
        }
        const flag = best <= alphaOriginal ? 'upper' : best >= beta ? 'lower' : 'exact';
        table.set(key, {depth,score:best,flag,best:bestMove});
        return best;
      };

      let rootResults = legal.map(move => ({move:move.uci, score:-INF}));
      let completedDepth = 0;
      let previousBest = null;
      for (let depth = 1; depth <= maxDepth; depth++) {
        if (stopped) break;
        const ordered = this.orderMoves(chess, legal.slice(), previousBest);
        const iteration = [];
        for (const move of ordered) {
          if (stopped) break;
          chess.move(move.uci, {skipSan:true});
          // Full root windows keep candidate scores comparable; narrow windows here would
          // turn ordinary fail-high bounds into false ties and could hide a mate-in-one.
          const score = -negamax(chess, depth - 1, -INF, INF, 1);
          chess.undo();
          iteration.push({move:move.uci,score});
        }
        if (iteration.length === legal.length) {
          rootResults = iteration;
          rootResults.sort((a,b) => b.score - a.score);
          completedDepth = depth;
          previousBest = rootResults[0]?.move || previousBest;
        }
        if (now() >= deadline || nodes >= nodeLimit) break;
      }

      if (completedDepth === 0) {
        // If a small device hits its search budget early, fall back to a completed one-ply evaluation.
        rootResults = legal.map(move => {
          chess.move(move.uci, {skipSan:true});
          const score = -this.evaluate(chess, chess.turn());
          chess.undo();
          return {move:move.uci, score};
        });
      }

      const exploration = clamp(190 - (this.data.traits.curious || 50) * 1.25, 45, 150);
      const mirrorIsLegal = !!mirroredHabit && legal.some(move => move.uci === mirroredHabit);
      const mirrorProbability = mirrorIsLegal
        ? Math.min(0.72, 0.22 + Math.log2(1 + mirroredHabitCount) * 0.18)
        : 0;
      const mirrorRoll = hash32(`${memoryKey}|${mirroredHabit}|${this.data.games}|habit`) / 0xffffffff;
      const mirrorThisTurn = mirrorIsLegal && mirrorRoll < mirrorProbability ? mirroredHabit : null;
      const chooseScore = item => {
        const learned = remembered[item.move]?.score || 0;
        // Never let curiosity noise or old memories override a forced mate score.
        if (Math.abs(item.score) >= MATE - 1000) return item.score * 100 + learned;
        const replyHabit = book[item.move] ? Math.min(180, 50 + book[item.move].count * 18 + book[item.move].score * 2) : 0;
        // Habit mirroring is an actual frequency-based chance, not a tiny score nudge
        // that search noise can routinely erase. It still yields to normal play otherwise.
        const mirrorHabit = mirrorThisTurn && item.move === mirrorThisTurn ? 1800 : 0;
        const deterministicNoise = ((hash32(`${memoryKey}|${item.move}|${this.data.games}`) / 0xffffffff) - 0.5) * exploration;
        return item.score + learned * 2.4 + replyHabit + mirrorHabit + deterministicNoise;
      };
      rootResults.sort((a,b) => chooseScore(b) - chooseScore(a));
      const result = {move:rootResults[0]?.move || legal[0].uci, depth:completedDepth,nodes,score:rootResults[0]?.score ?? null,elapsed:now()-start,mirrorProbability,mirrored:!!mirrorThisTurn};
      this.lastSearch = result;
      return result;
    }

    updateMaterialGenes(outcome) {
      // Piece values adapt only from this pet's own game record. There is no hidden target
      // table pulling the values toward conventional chess values after each result.
      const reward = outcome === 'win' ? 1 : outcome === 'loss' ? -1 : 0;
      for (const p of TYPES) {
        const exposure = clamp(Number(this.data.geneticTrace[p]) || 0, 0, 8);
        this.data.weights[p] = Math.round(clamp(this.data.weights[p] + reward * exposure * 10, 65, 1500));
      }
    }

    reinforce(outcome, finalPosition = null) {
      if (outcome === 'practice') {
        this.data.practiceGames++;
        // A completed self-play game can resolve its final pending decision from the
        // result for that colour. This is learning feedback only, never a pet win/loss.
        const result = finalPosition && typeof finalPosition.result === 'function' ? finalPosition.result() : null;
        if (result === 'w' || result === 'b' || result === 'draw') {
          for (const item of this.data.pending.filter(entry => !entry.r)) {
            const moveResult = result === 'draw' ? 'draw' : item.side === result ? 'win' : 'loss';
            const reward = moveResult === 'win' ? 15 : moveResult === 'loss' ? -20 : 2;
            const rewardUnit = moveResult === 'win' ? 1 : moveResult === 'loss' ? -1 : 0.15;
            const entry = this.entry(item.f, item.m);
            entry.score = clamp(entry.score + reward, -100, 100);
            entry.outcomes++;
            for (const [name, change] of Object.entries(item.d || {})) {
              this.data.policy[name] = clamp((this.data.policy[name] || 0) + Number(change || 0) * rewardUnit * 0.12, -250, 250);
            }
          }
        }
        // Self-play never changes Growth Elo, Arena Elo, wins, losses or draws.
        this.data.pending = [];
        this.data.geneticTrace = {p:0,n:0,b:0,r:0,q:0};
        this.data.lastHumanMove = null;
        this.save();
        return;
      }
      const baseReward = outcome === 'win' ? 15 : outcome === 'loss' ? -20 : 2;
      const rewardUnit = outcome === 'win' ? 1 : outcome === 'loss' ? -1 : 0.15;
      const n = this.data.pending.length;
      for (let i=0;i<n;i++) {
        const item = this.data.pending[i];
        const entry = this.entry(item.f, item.m);
        const recency = Math.pow(0.94, n - 1 - i);
        entry.score = clamp(entry.score + baseReward * recency, -100, 100);
        entry.outcomes++;
        entry.last = now();
        for (const [name, change] of Object.entries(item.d || {})) {
          this.data.policy[name] = clamp((this.data.policy[name] || 0) + Number(change || 0) * rewardUnit * 0.12 * recency, -250, 250);
        }
      }

      if (finalPosition) this.recordGeneticPosition(finalPosition, 'b');
      this.data.games++;
      this.updateMaterialGenes(outcome);
      if (outcome === 'win') this.data.wins++;
      else if (outcome === 'loss') this.data.losses++;
      else this.data.draws++;

      // Provisional local Growth Elo is deliberately separate from Arena Elo.
      const baseline = this.data.trainerReferenceElo || 1000;
      const expected = 1 / (1 + Math.pow(10, (baseline - this.data.elo) / 400));
      const actual = outcome === 'win' ? 1 : outcome === 'draw' ? 0.5 : 0;
      const delta = Math.round(24 * (actual - expected));
      this.data.elo = Math.max(100, this.data.elo + delta);
      this.data.gen = 1 + Math.floor(Math.max(0, this.data.elo - 100) / 250);
      this.data.pending = [];
      this.data.geneticTrace = {p:0,n:0,b:0,r:0,q:0};
      this.data.lastHumanMove = null;
      this.save();
    }

    resetPending() {
      this.data.pending = [];
      this.data.geneticTrace = {p:0,n:0,b:0,r:0,q:0};
      this.data.lastHumanMove = null;
      this.save();
    }

    exportSoul(activeMatch = null) {
      const result = {format:'Chessling Soul',version:3,encoding:'compact-json-v3',exportedAt:new Date().toISOString(),pet:this.compactData()};
      if (activeMatch) result.activeMatch = activeMatch;
      const json = JSON.stringify(result, null, 2);
      if (this.size() > LIMIT) throw new Error('Chessling brain exceeds the 50 KiB budget.');
      return json;
    }

    importSoul(object) {
      const source = object?.pet || object;
      const expanded = this.expandData(source);
      if (!expanded || typeof expanded !== 'object' || !expanded.weights || !expanded.memory) throw new Error('This is not a valid Chessling Soul.');
      const incoming = this.normalise(expanded);
      if (byteLength(this.compactData(incoming)) > LIMIT) throw new Error('This Soul is larger than the 50 KiB brain budget.');
      const previous = this.data;
      this.data = incoming;
      try { this.save(); }
      catch (error) { this.data = previous; throw error; }
      if (this.size() > LIMIT) { this.data = previous; throw new Error('Soul exceeds the 50 KiB brain budget.'); }
      return object?.activeMatch || null;
    }
  }

  const root = typeof window !== 'undefined' ? window : globalThis;
  root.ChesslingBrain = ChesslingBrain;
  root.CHESSLING_BRAIN_LIMIT = LIMIT;
})();
