/**
 * PAWNLING — Optional Cloudflare D1 Arena & Web Crypto PIN Client
 * Works 100% offline first; connects when API_BASE_URL is configured.
 */
const PAWNLING_SYNC = {
  // Replace with your Cloudflare Worker URL once deployed:
  API_BASE_URL: 'https://pawnling-arena.your-subdomain.workers.dev',

  async hashPin(pin) {
    if (!pin) return '';
    const encoder = new TextEncoder();
    const data = encoder.encode('pawnling_salt_v1_' + pin.trim());
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  async syncPet(brainData, rawPin) {
    const pinHash = await this.hashPin(rawPin);
    if (pinHash) {
      localStorage.setItem('pawnling_pin_hash_' + brainData.handle, pinHash);
    }
    const savedHash = pinHash || localStorage.getItem('pawnling_pin_hash_' + brainData.handle) || '';

    const res = await fetch(`${this.API_BASE_URL}/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Pin-Hash': savedHash
      },
      body: JSON.stringify({
        pet_name: brainData.handle,
        display_name: brainData.petName,
        trainer_name: brainData.trainerName,
        elo: brainData.elo,
        wins: brainData.wins,
        losses: brainData.losses,
        gen: brainData.gen,
        brain: brainData
      })
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(errText || 'Sync failed');
    }
    return await res.json();
  },

  async fetchLeaderboard() {
    const res = await fetch(`${this.API_BASE_URL}/leaderboard`);
    if (!res.ok) throw new Error('Could not load leaderboard');
    return await res.json();
  },

  async fetchBotByHandle(handle) {
    const res = await fetch(`${this.API_BASE_URL}/bot/${encodeURIComponent(handle)}`);
    if (!res.ok) throw new Error('Pawnling not found in D1 Arena');
    return await res.json();
  }
};
