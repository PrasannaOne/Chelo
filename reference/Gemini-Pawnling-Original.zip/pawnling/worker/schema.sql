-- Cloudflare D1 Schema for Pawnling Global Arena
CREATE TABLE IF NOT EXISTS pets (
  pet_name TEXT PRIMARY KEY,          -- Unique lowercase handle, e.g. "pawn_eater"
  display_name TEXT DEFAULT 'Baby Pawnling',
  trainer_name TEXT DEFAULT 'Anon',   -- Non-unique trainer display name
  pin_hash TEXT DEFAULT '',           -- Optional SHA-256 hash of owner's 8-digit PIN
  is_pro INTEGER DEFAULT 0,           -- 1 if trainer has Crown Badge / Nursery Pro
  elo INTEGER DEFAULT 200,
  wins INTEGER DEFAULT 0,
  losses INTEGER DEFAULT 0,
  gen INTEGER DEFAULT 1,
  brain_json TEXT NOT NULL,           -- Compact ~10-50KB JSON (capped at 1,000 FEN states)
  updated_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_pets_elo ON pets(elo DESC);
