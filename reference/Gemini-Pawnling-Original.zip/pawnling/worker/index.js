/**
 * PAWNLING — Cloudflare Worker + D1 SQLite Backend
 * Free Tier: 100,000 writes/day, 5,000,000 reads/day, 5 GB total storage
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Pin-Hash'
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // 1. GET /leaderboard — Top 25 Monster Pawnlings
    if (url.pathname === '/leaderboard' && request.method === 'GET') {
      const { results } = await env.DB.prepare(
        'SELECT pet_name, display_name, trainer_name, is_pro, elo, wins, losses, gen FROM pets ORDER BY elo DESC LIMIT 25'
      ).all();
      return Response.json(results, { headers: corsHeaders });
    }

    // 2. GET /bot/:name — Load a specific Pawnling to challenge via ?bot=pet_name
    if (url.pathname.startsWith('/bot/') && request.method === 'GET') {
      const handle = url.pathname.replace('/bot/', '').toLowerCase().replace(/[^a-z0-9_]/g, '');
      const pet = await env.DB.prepare('SELECT * FROM pets WHERE pet_name = ?').bind(handle).first();
      if (!pet) {
        return new Response('Pawnling not found', { status: 404, headers: corsHeaders });
      }
      delete pet.pin_hash; // Never expose owner's PIN hash
      return Response.json(pet, { headers: corsHeaders });
    }

    // 3. POST /sync — Claim or update a Pawnling (Protected by optional 8-digit PIN hash)
    if (url.pathname === '/sync' && request.method === 'POST') {
      const body = await request.json();
      const handle = (body.pet_name || '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20);
      const pinHash = request.headers.get('X-Pin-Hash') || '';

      if (!handle) {
        return new Response('Invalid @pet_name handle', { status: 400, headers: corsHeaders });
      }

      const brainStr = JSON.stringify(body.brain || {});
      if (brainStr.length > 150000) {
        return new Response('Brain JSON exceeds 150KB safety limit', { status: 413, headers: corsHeaders });
      }

      const existing = await env.DB.prepare('SELECT pin_hash FROM pets WHERE pet_name = ?').bind(handle).first();

      if (existing) {
        if (existing.pin_hash && existing.pin_hash !== pinHash) {
          return new Response('Locked: Incorrect 8-digit PIN for @' + handle, { status: 403, headers: corsHeaders });
        }
        await env.DB.prepare(
          `UPDATE pets
           SET display_name = ?, trainer_name = ?, elo = ?, wins = ?, losses = ?, gen = ?, brain_json = ?, updated_at = ?
           WHERE pet_name = ?`
        ).bind(
          body.display_name || 'Pawnling',
          body.trainer_name || 'Anon',
          body.elo || 200,
          body.wins || 0,
          body.losses || 0,
          body.gen || 1,
          brainStr,
          Date.now(),
          handle
        ).run();
      } else {
        await env.DB.prepare(
          `INSERT INTO pets (pet_name, display_name, trainer_name, pin_hash, elo, wins, losses, gen, brain_json, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(
          handle,
          body.display_name || 'Pawnling',
          body.trainer_name || 'Anon',
          pinHash,
          body.elo || 200,
          body.wins || 0,
          body.losses || 0,
          body.gen || 1,
          brainStr,
          Date.now()
        ).run();
      }

      return Response.json({ ok: true, pet_name: handle }, { headers: corsHeaders });
    }

    // 4. POST /challenge — Stranger finishes a match against a shared Pawnling
    if (url.pathname === '/challenge' && request.method === 'POST') {
      const { pet_name, challenger_won, move_count } = await request.json();
      const handle = (pet_name || '').toLowerCase().replace(/[^a-z0-9_]/g, '');

      // Basic sanity check: require at least 8 plies (4 full moves) for ranked Elo changes
      if (!handle || (move_count || 0) < 8) {
        return new Response('Match too short for ranked Elo update', { status: 400, headers: corsHeaders });
      }

      const eloDelta = challenger_won ? -10 : 12;
      const winInc = challenger_won ? 0 : 1;
      const lossInc = challenger_won ? 1 : 0;

      await env.DB.prepare(
        `UPDATE pets
         SET elo = MAX(100, elo + ?), wins = wins + ?, losses = losses + ?, updated_at = ?
         WHERE pet_name = ?`
      ).bind(eloDelta, winInc, lossInc, Date.now(), handle).run();

      return Response.json({ ok: true }, { headers: corsHeaders });
    }

    return new Response('Pawnling D1 Arena API is running.', { headers: corsHeaders });
  }
};
