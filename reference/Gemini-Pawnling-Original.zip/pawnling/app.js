/**
 * PAWNLING — Main Mobile-First UI & Tap-to-Move Controller
 */
const PIECE_UNICODE = {
  wp: '♙', wn: '♘', wb: '♗', wr: '♖', wq: '♕', wk: '♔',
  bp: '♟', bn: '♞', bb: '♝', br: '♜', bq: '♛', bk: '♚'
};

const chess = new Chess();
const brain = new PawnlingBrain('pawnling_slot_1');
let selectedSquare = null;
let validMovesForSelected = [];
let botHistoryLog = [];
let isProUnlocked = localStorage.getItem('pawnling_pro_unlocked') === 'true';

// Register Offline Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

function initApp() {
  updateProUI();
  renderBoard();
  updatePetUI();
  bindEvents();
}

function renderBoard() {
  const boardEl = document.getElementById('chessboard');
  boardEl.innerHTML = '';
  const boardData = chess.board();

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const file = 'abcdefgh'[c];
      const rank = 8 - r;
      const sqName = `${file}${rank}`;

      const sqDiv = document.createElement('div');
      sqDiv.className = `square ${(r + c) % 2 === 0 ? 'light' : 'dark'}`;
      if (selectedSquare === sqName) sqDiv.classList.add('selected');
      if (validMovesForSelected.some(m => m.to === sqName)) {
        sqDiv.classList.add('valid-move');
      }

      const piece = boardData[r][c];
      if (piece) {
        const span = document.createElement('span');
        span.className = `piece-${piece.color}`;
        span.textContent = PIECE_UNICODE[piece.color + piece.type];
        sqDiv.appendChild(span);
      }

      sqDiv.addEventListener('click', () => onSquareTap(sqName));
      boardEl.appendChild(sqDiv);
    }
  }
}

function onSquareTap(sqName) {
  if (chess.game_over() || chess.turn() !== 'w') return;

  // Check if tapping a valid destination square
  const moveObj = validMovesForSelected.find(m => m.to === sqName);
  if (selectedSquare && moveObj) {
    const fenBefore = chess.fen();
    const moveDone = chess.move({
      from: selectedSquare,
      to: sqName,
      promotion: 'q'
    });

    if (moveDone) {
      brain.recordHumanMove(fenBefore, moveDone.san);
      selectedSquare = null;
      validMovesForSelected = [];
      renderBoard();

      if (checkGameEnd()) return;

      document.getElementById('turnBanner').textContent = `${brain.data.petName} is thinking...`;
      setTimeout(makeBotMove, 260);
      return;
    }
  }

  // Otherwise select a white piece
  const piece = chess.get(sqName);
  if (piece && piece.color === 'w') {
    selectedSquare = sqName;
    validMovesForSelected = chess.moves({ square: sqName, verbose: true });
  } else {
    selectedSquare = null;
    validMovesForSelected = [];
  }
  renderBoard();
}

function makeBotMove() {
  if (chess.game_over()) return;
  const moveSan = brain.chooseMove(chess, botHistoryLog);
  if (moveSan) chess.move(moveSan);
  renderBoard();
  if (!checkGameEnd()) {
    document.getElementById('turnBanner').textContent = 'Your Turn (White) — Tap a piece to move';
  }
}

function checkGameEnd() {
  if (!chess.game_over()) return false;

  let outcome = 'draw';
  let bannerText = 'Match Drawn! Both learned something.';
  let speech = '"A draw! My circuits are getting sharper."';

  if (chess.in_checkmate()) {
    if (chess.turn() === 'w') {
      // Bot won (Black checkmated White)
      outcome = 'win';
      bannerText = `${brain.data.petName} Checkmated You!`;
      speech = '"I WON?! Lock those move weights in!"';
    } else {
      // Human won (White checkmated Black)
      outcome = 'loss';
      bannerText = `You Checkmated ${brain.data.petName}!`;
      speech = '"Oof! Mutating my piece weights so I don't fall for that again..."';
    }
  }

  brain.learnFromMatch(outcome, botHistoryLog);
  document.getElementById('turnBanner').textContent = bannerText;
  document.getElementById('petSpeech').textContent = speech;
  updatePetUI();
  return true;
}

function updatePetUI() {
  const d = brain.data;
  document.getElementById('petNameDisplay').textContent = d.petName;
  document.getElementById('statGen').textContent = d.gen;
  document.getElementById('statElo').textContent = d.elo;
  document.getElementById('statWLD').textContent = `${d.wins}/${d.losses}/${d.draws}`;
  document.getElementById('statMem').textContent = Object.keys(d.memory).length;
  document.getElementById('iqScore').textContent = `IQ: ${brain.getEstimatedIQ()}`;

  // Evolve Pet Avatar based on Generation & Queen weight awareness
  const avatarEl = document.getElementById('petAvatar');
  const moodEl = document.getElementById('petMood');
  if (d.gen < 4) {
    avatarEl.textContent = '🐣';
    moodEl.textContent = 'Clueless Hatchling';
  } else if (d.gen < 12) {
    avatarEl.textContent = '🐥';
    moodEl.textContent = 'Apprentice Tactician';
  } else if (d.gen < 25) {
    avatarEl.textContent = '🦉';
    moodEl.textContent = 'Trap Hunter';
  } else {
    avatarEl.textContent = '🐉';
    moodEl.textContent = 'Grandmaster Monster';
  }

  // Update Live Piece Weight Bars (scaled against 950 max)
  for (const p of ['p', 'n', 'b', 'r', 'q']) {
    const val = d.weights[p] || 100;
    const pct = Math.min(100, Math.round((val / 950) * 100));
    document.getElementById(`bar-${p}`).style.width = `${pct}%`;
    document.getElementById(`val-${p}`).textContent = (val / 100).toFixed(1);
  }
}

function startNewGame() {
  chess.reset();
  selectedSquare = null;
  validMovesForSelected = [];
  botHistoryLog = [];
  document.getElementById('turnBanner').textContent = 'New Match Started — Your Turn (White)';
  renderBoard();
}

// Fast Self-Sparring Simulation (Trains the bot automatically)
function runAutoSpar() {
  const simChess = new Chess();
  const simHistory = [];
  let plies = 0;

  while (!simChess.game_over() && plies < 90) {
    const m = brain.chooseMove(simChess, simHistory);
    if (!m) break;
    simChess.move(m);
    plies++;
  }

  let res = 'draw';
  if (simChess.in_checkmate()) {
    res = simChess.turn() === 'w' ? 'win' : 'loss';
  } else {
    // Reward learning slightly during sparring
    res = Math.random() < 0.55 ? 'loss' : 'win';
  }

  brain.learnFromMatch(res, simHistory);
  updatePetUI();
  document.getElementById('petSpeech').textContent =
    `"Sparring complete (Gen ${brain.data.gen})! My Queen weight is now ${(brain.data.weights.q / 100).toFixed(1)}."`;
}

function updateProUI() {
  const badge = document.getElementById('proBadge');
  if (isProUnlocked) {
    badge.textContent = '👑 PRO NURSERY';
    badge.style.color = '#f1c40f';
    const opts = document.getElementById('slotSelect').options;
    for (let i = 1; i < opts.length; i++) {
      opts[i].text = `Slot ${i + 1} (Unlocked)`;
    }
  }
}

function bindEvents() {
  document.getElementById('newGameBtn').addEventListener('click', startNewGame);
  document.getElementById('sparBtn').addEventListener('click', runAutoSpar);

  document.getElementById('renameBtn').addEventListener('click', () => {
    const next = prompt('Name your Pawnling:', brain.data.petName);
    if (next && next.trim()) {
      brain.data.petName = next.trim().slice(0, 22);
      brain.save();
      updatePetUI();
    }
  });

  // Theme Switcher
  document.getElementById('themeSelect').addEventListener('change', (e) => {
    document.body.className = e.target.value;
  });

  // Nursery Slot Switcher
  document.getElementById('slotSelect').addEventListener('change', (e) => {
    const val = e.target.value;
    if (val !== 'pawnling_slot_1' && !isProUnlocked) {
      e.target.value = 'pawnling_slot_1';
      document.getElementById('proModal').classList.remove('hidden');
      return;
    }
    brain.switchSlot(val);
    startNewGame();
    updatePetUI();
  });

  // Export .json Soul
  document.getElementById('exportBtn').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(brain.data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(brain.data.petName || 'pawnling').toLowerCase().replace(/\s+/g, '_')}_soul.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // Import .json Soul
  const fileInput = document.getElementById('importFileInput');
  document.getElementById('importBtn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const imported = JSON.parse(ev.target.result);
        if (imported.weights && imported.memory) {
          brain.data = imported;
          brain.save();
          updatePetUI();
          document.getElementById('petSpeech').textContent = '"Soul restored successfully!"';
        }
      } catch {
        alert('Invalid Pawnling Soul JSON file.');
      }
    };
    reader.readAsText(file);
  });

  // Modals
  document.getElementById('syncModalBtn').addEventListener('click', () => {
    document.getElementById('inputPetHandle').value = brain.data.handle || '';
    document.getElementById('inputTrainerName').value = brain.data.trainerName || '';
    document.getElementById('arenaModal').classList.remove('hidden');
  });
  document.getElementById('closeArenaBtn').addEventListener('click', () => {
    document.getElementById('arenaModal').classList.add('hidden');
  });

  document.getElementById('proModalBtn').addEventListener('click', () => {
    document.getElementById('proModal').classList.remove('hidden');
  });
  document.getElementById('closeProBtn').addEventListener('click', () => {
    document.getElementById('proModal').classList.add('hidden');
  });

  document.getElementById('activateLicenseBtn').addEventListener('click', () => {
    const key = document.getElementById('licenseKeyInput').value.trim();
    if (key.length >= 6) {
      isProUnlocked = true;
      localStorage.setItem('pawnling_pro_unlocked', 'true');
      updateProUI();
      document.getElementById('proModal').classList.add('hidden');
      alert('👑 Pawnling Nursery Pro Unlocked!');
    }
  });

  // Cloud Sync Button
  document.getElementById('syncNowBtn').addEventListener('click', async () => {
    const handle = document.getElementById('inputPetHandle').value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    const trainer = document.getElementById('inputTrainerName').value.trim() || 'Anon';
    const pin = document.getElementById('inputPin').value.trim();
    const statusEl = document.getElementById('syncStatus');

    if (!handle) {
      statusEl.textContent = 'Please enter a unique @pet_name handle.';
      return;
    }
    brain.data.handle = handle;
    brain.data.trainerName = trainer;
    brain.save();

    statusEl.textContent = 'Syncing to Cloudflare D1...';
    try {
      await PAWNLING_SYNC.syncPet(brain.data, pin);
      statusEl.textContent = `✅ Synced! Share link: ?bot=${handle}`;
    } catch (err) {
      statusEl.textContent = `Offline / Worker not connected yet (${err.message}). Saved locally!`;
    }
  });
}

window.addEventListener('DOMContentLoaded', initApp);
