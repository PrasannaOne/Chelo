/**
 * PAWNLING — 3-Layer Self-Learning Chess Brain
 * Layer 1: Player Habit Mirroring (copies player's favorite opening moves)
 * Layer 2: FEN Trap Memory (rewards winning moves, punishes blunders/checkmates)
 * Layer 3: Genetic Piece Value Evolution (discovers P/N/B/R/Q values over time)
 */
class PawnlingBrain {
  constructor(storageKey = 'pawnling_slot_1') {
    this.storageKey = storageKey;
    this.MAX_POSITIONS = 1000; // Hard cap (~50KB max JSON size)
    this.data = this.load();
  }

  defaultBrain() {
    return {
      petName: 'Baby Pawnling',
      handle: '',
      trainerName: 'Anon',
      gen: 1,
      wins: 0,
      losses: 0,
      draws: 0,
      elo: 200,
      // Starts nearly clueless: treats a Queen (130) almost like a Pawn (100)
      weights: { p: 100, n: 110, b: 110, r: 120, q: 130, k: 9000 },
      // { simplifiedFen: { moveSan: { score: number, mirrorCount: number, lastUsed: number } } }
      memory: {}
    };
  }

  load() {
    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? Object.assign(this.defaultBrain(), JSON.parse(raw)) : this.defaultBrain();
    } catch {
      return this.defaultBrain();
    }
  }

  save() {
    this.pruneMemory();
    localStorage.setItem(this.storageKey, JSON.stringify(this.data));
  }

  switchSlot(newStorageKey) {
    this.storageKey = newStorageKey;
    this.data = this.load();
  }

  simplifyFen(fen) {
    // Keep board placement + active color only so identical positions match reliably
    return fen.split(' ').slice(0, 2).join(' ');
  }

  // Layer 1: Record what the human plays so Pawnling can mirror their style
  recordHumanMove(fenBefore, moveSan) {
    const key = this.simplifyFen(fenBefore);
    if (!this.data.memory[key]) this.data.memory[key] = {};
    if (!this.data.memory[key][moveSan]) {
      this.data.memory[key][moveSan] = { score: 0, mirrorCount: 0, lastUsed: Date.now() };
    }
    this.data.memory[key][moveSan].mirrorCount += 1;
    this.data.memory[key][moveSan].lastUsed = Date.now();
  }

  // Choose a move using Layer 1 (Mirroring), Layer 2 (Trap Memory), and Layer 3 (Genetic Minimax)
  chooseMove(chessInstance, botHistoryLog) {
    const moves = chessInstance.moves();
    if (moves.length === 0) return null;

    const fenKey = this.simplifyFen(chessInstance.fen());
    const mem = this.data.memory[fenKey];

    // Check Opening/Trap Memory first (first 12 full moves = 24 plies)
    if (mem && chessInstance.history().length < 24) {
      let bestMemMove = null;
      let bestMemScore = -Infinity;

      for (const m of moves) {
        if (mem[m]) {
          const combined = mem[m].score + (mem[m].mirrorCount * 9);
          if (combined > bestMemScore && combined > 4) {
            bestMemScore = combined;
            bestMemMove = m;
          }
        }
      }
      if (bestMemMove && Math.random() < 0.78) {
        botHistoryLog.push({ fen: fenKey, move: bestMemMove });
        return bestMemMove;
      }
    }

    // Layer 3: Shallow Minimax (Depth 2) with Alpha-Beta Pruning + Evolving Weights
    let bestMove = moves[Math.floor(Math.random() * moves.length)];
    let bestEval = -Infinity;

    for (const m of moves) {
      // Penalize moves that historically lost badly in this exact position
      let memoryBias = 0;
      if (mem && mem[m]) {
        memoryBias = mem[m].score * 2.5 + mem[m].mirrorCount * 5;
      }

      chessInstance.move(m);
      const score = -this.minimax(chessInstance, 1, -Infinity, Infinity) + memoryBias;
      chessInstance.undo();

      // Organic jitter decreases as Generation increases
      const noiseScale = Math.max(4, 25 - this.data.gen * 0.5);
      const jitter = (Math.random() - 0.5) * noiseScale;

      if (score + jitter > bestEval) {
        bestEval = score + jitter;
        bestMove = m;
      }
    }

    botHistoryLog.push({ fen: fenKey, move: bestMove });
    return bestMove;
  }

  minimax(chess, depth, alpha, beta) {
    if (depth === 0 || chess.game_over()) {
      return this.evaluateBoard(chess);
    }
    const moves = chess.moves();
    let maxEval = -Infinity;
    for (const m of moves) {
      chess.move(m);
      const ev = -this.minimax(chess, depth - 1, -beta, -alpha);
      chess.undo();
      if (ev > maxEval) maxEval = ev;
      if (ev > alpha) alpha = ev;
      if (alpha >= beta) break;
    }
    return maxEval;
  }

  evaluateBoard(chess) {
    if (chess.in_checkmate()) return -99999;
    if (chess.in_draw() || chess.in_stalemate() || chess.in_threefold_repetition()) return 0;

    const board = chess.board();
    const turn = chess.turn();
    let total = 0;

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (!piece) continue;
        const baseVal = this.data.weights[piece.type] || 100;
        // Center control bonus (rows 3-4, cols 3-4)
        const centerBonus = (r >= 2 && r <= 5 && c >= 2 && c <= 5) ? 8 : 0;
        const val = baseVal + centerBonus;
        total += (piece.color === turn) ? val : -val;
      }
    }
    return total;
  }

  learnFromMatch(result, botHistoryLog) {
    // result: 'win' | 'loss' | 'draw'
    const delta = result === 'win' ? 15 : result === 'loss' ? -20 : 3;

    // Update FEN Trap Memory
    for (const entry of botHistoryLog) {
      if (!this.data.memory[entry.fen]) this.data.memory[entry.fen] = {};
      if (!this.data.memory[entry.fen][entry.move]) {
        this.data.memory[entry.fen][entry.move] = { score: 0, mirrorCount: 0, lastUsed: Date.now() };
      }
      this.data.memory[entry.fen][entry.move].score += delta;
      this.data.memory[entry.fen][entry.move].lastUsed = Date.now();
    }

    // Evolve piece weights toward discovering true material value
    const trueTargets = { p: 100, n: 320, b: 330, r: 500, q: 900 };
    const learnRate = result === 'loss' ? 0.14 : 0.06;

    for (const p of ['p', 'n', 'b', 'r', 'q']) {
      const diff = trueTargets[p] - this.data.weights[p];
      const mutation = (Math.random() - 0.42) * 14;
      this.data.weights[p] = Math.max(
        80,
        Math.min(980, Math.round(this.data.weights[p] + diff * learnRate + mutation))
      );
    }

    if (result === 'win') {
      this.data.wins += 1;
      this.data.elo += 18;
    } else if (result === 'loss') {
      this.data.losses += 1;
      this.data.elo = Math.max(100, this.data.elo - 10);
    } else {
      this.data.draws += 1;
      this.data.elo += 4;
    }

    this.data.gen += 1;
    this.save();
  }

  getEstimatedIQ() {
    const w = this.data.weights;
    const sum = w.p + w.n + w.b + w.r + w.q;
    const memCount = Object.keys(this.data.memory).length;
    return Math.round((sum / 10) + (memCount * 0.4));
  }

  pruneMemory() {
    const keys = Object.keys(this.data.memory);
    if (keys.length <= this.MAX_POSITIONS) return;

    keys.sort((a, b) => {
      const aLast = Math.max(...Object.values(this.data.memory[a]).map(x => x.lastUsed || 0));
      const bLast = Math.max(...Object.values(this.data.memory[b]).map(x => x.lastUsed || 0));
      return aLast - bLast;
    });

    const removeCount = keys.length - this.MAX_POSITIONS;
    for (let i = 0; i < removeCount; i++) {
      delete this.data.memory[keys[i]];
    }
  }
}
