# Upload Chelo.zip to the Chelo repository

1. Open https://github.com/PrasannaOne/Chelo.
2. Choose **Add file → Upload files**.
3. Upload this archive as `Chelo.zip` in the repository root. Do not upload it inside a folder.
4. Commit the upload to `main`.
5. Open **Actions → Install Chelo project archive**. It validates the archive, runs core engine checks, prepares a Pages artifact, and installs the project files into the repository root.
6. After the installer succeeds, the separate **Deploy Chelo to GitHub Pages** workflow publishes the root site.

## Archive layout rule

The ZIP's top level must contain project files directly: `index.html`, `cpp/`, `src/`, `models/`, `tests/`, and so on. Do not wrap them in `Chelo-V15-CPP-M8/` or another outer directory.

## What the installer preserves

- Existing `.git` history and `.github` workflow definitions.
- Existing repository files not replaced by the Chelo archive.
- The uploaded `Chelo.zip` itself.

The uploaded archive must not contain `.git`, `.env` secret files, compiled native build outputs, or path traversal entries.
