# Chelo V14 · Stage 3.9

Chelo is an offline-first chess companion with an incrementally updated dual-perspective NNUE search evaluator, per-pet V15 Soul memories/adapters, and an optional account-backed Arena service.

## Repository layout

```text
index.html
manifest.webmanifest
sw.js
_headers
assets/
  style.css
  icon.svg
  pieces.svg
src/
  app/app.js
  engine/                 # ChessCore, FastBoard search, Polyglot, KPK
  nnue/dual-nnue.js        # C36N binary parser
  soul/brain.js           # pet learning, V15 Soul + LoRA serialization
  worker/ai-worker.js     # browser worker + optional Lazy SMP pool
models/
  dual-nnue-v37.bin       # pinned Stage 3.7 model, 49,368 bytes
  base-v14-float32.json   # active legacy pet-learning base, not the search NNUE
  polyglot-book.bin
  kpk-wdl.bin
  *.manifest.json / *.sha256
workers/arena/            # Cloudflare Worker, D1 schema and migrations
training/                 # PyTorch/CUDA QAT trainer and training notes
tools/                    # reproducible data-generation utilities
benchmarks/               # focused tactical data, paired results and V8 profiles
tests/                    # engine, Soul, worker, repository, TT and tactical tests
docs/                     # engineering audit, migration and deployment notes
```

## Build and test

There is no frontend bundler and no runtime CDN dependency. `build-static.sh` copies only the deployable runtime tree into `_site/`, excluding tests, historical benchmarks and development documentation. Tests are split into core, worker/Arena, and long-form learning suites so each can run independently.

```sh
./run-tests.sh
./run-search-tests.sh
./run-nnue-tests.sh
./run-worker-tests.sh
./run-tactical-tests.sh
./run-learning-tests.sh
./run-v8-profile.sh
```

To repeat the warmed V8 GC/deoptimization profile:

```sh
node --trace-gc --trace-deopt tests/runtime-profile.js > /tmp/chelo-v8-profile.txt 2>&1
```

## GitHub Pages

1. Create or use the repository named `Chelo` under `prasannaone`.
2. Push this repository to the `main` branch.
3. Enable GitHub Pages with **GitHub Actions** as the source.
4. The included `.github/workflows/pages.yml` runs `build-static.sh` and deploys `_site/`.

The site uses relative URLs throughout, so a project-site URL such as `https://prasannaone.github.io/Chelo/` works without a hard-coded origin. `.nojekyll` is included. GitHub Pages does not let this repository set COOP/COEP response headers; when `crossOriginIsolated` is unavailable, Apex safely falls back to one worker.

## Cloudflare Pages + Arena Worker

- Connect the same Git repository to Cloudflare Pages with no build command and the repository root as the output directory.
- Cloudflare Pages applies `_headers`, including COOP/COEP, so supported browsers can use `SharedArrayBuffer` and the four-worker Apex pool.
- The Arena API is a separate Worker in `workers/arena/`. Set the D1 `database_id` and `CORS_ORIGIN` in `workers/arena/wrangler.toml` before deploying it with Wrangler.
- The static chess app remains usable without the Arena Worker or an account.

## Model integrity

`models/dual-nnue-v37.bin` is exactly 49,368 bytes and is pinned to:

`f9ffe3f0dc641c93be26f871086182a82291411a4e4b59c073fcc7c8bfc4022e`

Both the page's main-thread fallback and the AI Worker verify this SHA-256 before parsing the C36N v1 model. The service worker precaches the model and every runtime module.

## Important compatibility note

The V14-named Float32 checkpoint and related pet-learning/LoRA code are still active: `brain.js` uses them for the pet's separate learning model and V15 Soul migration. They are not a duplicate copy of the Stage 3.7 search evaluator. Stage 3.8 therefore removes stale V14 *search wiring* and redundant references, but deliberately retains the active pet-learning base and compatibility paths.

New exports use the Chelo Soul label. Import continues to accept older Chessling-branded V15 Souls and Bond/Arena LoRA files, plus earlier supported Soul versions. Legacy runtime globals and localStorage keys are retained only as migration aliases.

## Validation limits

The included tactical retention dataset contains 50 mate-in-one positions. Stage 3.8 passes all 50 at a fixed 8,000-node budget, matching the Stage 3.6 bootstrap reference. This is a narrow tactical subset, not a full Win At Chess, Eigenmann or STS suite. V8 profiling was run in Node.js isolates in the build environment, not on physical Android/MediaTek devices. See `docs/ENGINEERING-AUDIT.md` for exact scope.

## UCI engine testing (Node.js)

Chelo includes a development-only UCI adapter at `src/uci/chelo-uci.js`. It loads the pinned dual-perspective NNUE model, verifies its SHA-256, and exposes the Stage 3.9 FastSearch engine to standard UCI clients. It is not part of the browser/PWA runtime.

To run the paired 60-game match, place the `tomitankChess` repository beside the Chelo repository so `../tomitankChess/tomitankChessUCI.js` exists, then run:

```sh
node tests/uci-gauntlet.js
```

The gauntlet cycles through ten legal opening positions and plays every opening twice, swapping Chelo's colours for the second game. Defaults are 60 games, 500 ms per move, and a 240-ply safety limit. Optional controls:

```sh
node tests/uci-gauntlet.js --games 20 --movetime 300 --max-plies 180
```

The final report prints Chelo's Wins/Losses/Draws, score percentage, and Elo difference relative to Tomitank, calculated from the match score using the standard logistic Elo expectation. This is a head-to-head estimate, not a published rating or a substitute for a larger controlled rating run.
