# Chelo Soul migration compatibility

- Current full Soul version remains **V15**.
- New full exports use `format: "Chelo Soul"`.
- New standalone adapter exports use `format: "Chelo Dual LoRA"`.
- Import accepts the previous `Chessling Soul` and `Chessling Dual LoRA` format labels as well as the new Chelo labels.
- V15 `Bond_LoRA` rank-1 and `Arena_LoRA` rank-2 tensors retain their existing packed representation and fixed-point bias-delta application.
- V13/V14 full Souls continue to import through the existing migration path. Older supported V4–V12 migration tests remain in the suite.
- The shared C36N base model is never replaced by imported Soul data; Souls carry pet identity, memories and adapter state only.
- Existing browser saves under `chessling_pet_1` are copied to `chelo_pet_1` on first launch if no Chelo save exists. Legacy keys remain intact during the copy.
- The previous `ChesslingBrain`, `ChesslingDualNNUE`, `ChesslingFastSearch` and Polyglot globals remain aliases for older integrations. New app code uses Chelo globals.

A compatibility test imports a legacy-branded V15 full Soul and confirms bit-identical Bond/Arena adapter tensors.
