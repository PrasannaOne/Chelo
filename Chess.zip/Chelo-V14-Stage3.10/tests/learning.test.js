const fs=require('fs');
const vm=require('vm');
const path=require('path');
const context={window:{},TextEncoder,Date,Math,console};context.self=context.window;
vm.createContext(context);
for(const file of ['src/engine/polyglot-random.js','src/engine/chess.js','src/soul/brain.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),context,{filename:file});
const Chess=context.window.ChessCore,Brain=context.window.ChesslingBrain;
function assert(ok,message){if(!ok)throw new Error(message);}

// Explicit seeds make the research harness reproducible without reseeding a live local save.
const seededA=new Brain('seeded_a',{persist:false,seed:123456});
const seededB=new Brain('seeded_b',{persist:false,seed:123456});
assert(seededA.data.model.w1.every((value,index)=>value===seededB.data.model.w1[index])&&seededA.data.model.wOut.every((value,index)=>value===seededB.data.model.wOut[index]),'Identically seeded fresh models must have identical initial value weights.');

const pet=new Brain('learning',{persist:false});
assert(pet.predict(Array(80).fill(0))===0,'An empty sparse vector must have zero activation.');
assert(pet.data.model.w1.length===784*48&&pet.data.model.w2.length===48*48,'V6 residual model must use a 784→48 input trunk plus a 48-unit residual refinement block.');
assert(context.window.CHESSLING_MODEL_PARAMETERS===47694,'V13 model parameter accounting is incorrect.');
assert(pet.data.model.w2.every(value=>value===0),'Residual refinement must start at zero to preserve older model predictions.');
assert(pet.data.model.wOut.length===144&&pet.predictWDL(Array(80).fill(0)).win+pet.predictWDL(Array(80).fill(0)).draw+pet.predictWDL(Array(80).fill(0)).loss>0.999,'WDL outcome head is missing or probabilities do not normalise.');
assert(pet.data.model.pFrom.length===64*48&&pet.data.model.pTo.length===64*48&&pet.data.model.pPiece.length===6*48&&pet.data.model.pPromo.length===5*48,'Context-conditioned policy embedding structure is incomplete.');

// Piece-centric encoding: the same board is mirrored into a side-relative frame.
const position=new Chess('4k3/8/8/8/8/8/8/R3K3 w - - 0 1');
const white=pet.extractFeatures(position,'w'),black=pet.extractFeatures(position,'b');
assert(white.length===80&&black.length===80,'Expected sparse 80-value board vector.');
assert(white[56]===4,'White rook on a1 should occupy its side-relative square plane.');
assert(black[7]===10,'White rook should become the opponent rook plane at rotated square h8 from Black perspective.');
assert(white[64]===1&&black[64]===0,'Side-to-move flag should reflect the requested side perspective.');
assert(pet.featuresFromFen(position.fen()).length===80,'FEN encoder did not return the side-relative vector.');

// Genuine gradient training must change the value model and learn a simple signal.
const trainingBoard=new Chess('4k3/8/8/8/8/8/8/R3K3 w - - 0 1');
const x=pet.extractFeatures(trainingBoard,'w');
assert(Math.abs(pet.predict(x))<0.15,'Fresh V6 value predictions should be small and untrained, not carry a strong preset.');
const beforeW1=pet.data.model.w1.slice(),beforeW2=pet.data.model.w2.slice(),beforeWOut=pet.data.model.wOut.slice();
for(let i=0;i<1200;i++)pet.trainSample(x,0.8,1);
const predicted=pet.predict(x);
assert(predicted>0.55,`Value model failed to learn a repeated target (${predicted.toFixed(3)}).`);
assert(pet.data.model.steps===1200,'Value training-step count incorrect.');
// WDL head must learn all three outcome classes, not only a scalar proxy.
for(const [label,target,expected] of [['win',1,'win'],['draw',0,'draw'],['loss',-1,'loss']]){
  const classifier=new Brain('wdl_'+label,{persist:false,seed:700+target+1});
  for(let i=0;i<900;i++)classifier.trainSample(x,target,1);
  const probs=classifier.predictWDL(x);
  assert(probs[expected]>0.72,`WDL head failed to learn ${label}: ${JSON.stringify(probs)}`);
  assert(Math.abs(probs.win+probs.draw+probs.loss-1)<1e-8,'WDL probabilities must sum to one.');
}

assert(pet.data.model.w1.some((v,i)=>v!==beforeW1[i])&&pet.data.model.w2.some((v,i)=>v!==beforeW2[i])&&pet.data.model.wOut.some((v,i)=>v!==beforeWOut[i]),'Backprop must update the input trunk, residual block and WDL output weights.');

// Policy head should learn to prefer the rewarded move over a contrasting move.
const disabledPolicyPet=new Brain('policy_disabled',{persist:false,policyLearning:false});
const disabledPolicyStart=new Chess(),disabledFeatures=disabledPolicyPet.extractFeatures(disabledPolicyStart,'w');
disabledPolicyPet.trainPolicyChoice(disabledFeatures,'e2e4',disabledPolicyStart.moves({verbose:true,skipSan:true}),'w',0.9,1);
assert(disabledPolicyPet.data.model.policySteps===0,'Policy ablation must be able to disable policy-gradient updates cleanly.');

const policyPet=new Brain('policy',{persist:false});const start=new Chess();const startFeatures=policyPet.extractFeatures(start,'w');
const legalStart=start.moves({verbose:true,skipSan:true}).map(move=>move.uci);
for(let i=0;i<700;i++){
  policyPet.trainPolicyChoice(startFeatures,'e2e4',legalStart,'w',0.9,1);
  policyPet.trainPolicyChoice(startFeatures,'d2d4',legalStart,'w',-0.9,1);
}
const policy=policyPet.policyDistribution(startFeatures,legalStart,'w');
const e4prior=policy.get('e2e4')||0,d4prior=policy.get('d2d4')||0;
assert(e4prior>d4prior+0.15,`Context-conditioned policy did not learn a move preference (${e4prior.toFixed(3)} vs ${d4prior.toFixed(3)}).`);
assert(policyPet.data.model.policySteps===1400,'Policy update counter incorrect.');
const policyOrdered=policyPet.orderMoves(start,start.moves({verbose:true,skipSan:true}));
assert(policyOrdered.findIndex(move=>move.uci==='e2e4')<policyOrdered.findIndex(move=>move.uci==='d2d4'),'Learned legal-move prior is not influencing search move ordering.');
const policyDisabledMove=policyPet.chooseMove(start,{timeMs:80,nodeLimit:1000,usePolicy:false});
assert(legalStart.includes(policyDisabledMove.move),'Search without the policy prior returned an illegal move.');

// Owner moves are observed, but frequency alone must never force a mirrored reply.
const habitBaseline=new Brain('habit_baseline',{persist:false,seed:991});
const habit=new Brain('habit',{persist:false,seed:991});
for(let i=0;i<20;i++)habit.observeHumanMove(start.fen(),'e2e4',1);
assert(habit.data.humanOpenings[habit.simplifyFen(start.fen())].e2e4.count===20,'Owner opening observations were not retained.');
const afterE4=new Chess();afterE4.move('e2e4');
const observedMove=habit.chooseMove(afterE4,{maxDepth:1,timeMs:5000,nodeLimit:10000});
const baselineMove=habitBaseline.chooseMove(afterE4,{maxDepth:1,timeMs:5000,nodeLimit:10000});
assert(observedMove.move===baselineMove.move,'Owner move frequency alone changed the selected move; direct mirroring must be removed.');
assert(!('mirrored' in observedMove)&&!('mirrorProbability' in observedMove),'Search must not report or depend on forced owner mirroring.');
// A frequently used pet opening is not rewarded unless its consequences have been learned.
const bookBaseline=new Brain('book_baseline',{persist:false,seed:992});
const bookBiased=new Brain('book_biased',{persist:false,seed:992});
bookBiased.data.openingReplies[bookBiased.simplifyFen(start.fen())]={'e2e4':{count:1000,score:100,last:Date.now()}};
const bookMoveA=bookBaseline.chooseMove(start,{maxDepth:1,timeMs:5000,nodeLimit:10000});
const bookMoveB=bookBiased.chooseMove(start,{maxDepth:1,timeMs:5000,nodeLimit:10000});
assert(bookMoveA.move===bookMoveB.move,'Raw opening frequency/score was incorrectly used as an unearned opening bonus.');

// TD feedback resolves a pet decision only after the opponent replies.
const td=new Brain('td',{persist:false});const game=new Chess();const beforeFen=game.fen();
const petMove=game.move('e2e4');td.observePetMove(beforeFen,petMove.uci,{piece:'p',side:'w'},1,game);
assert(td.data.pending.length===1&&!td.data.pending[0].r,'Move experience should remain pending until feedback.');
// Perturb the value baseline after action selection so the reply creates a
// measurable TD advantage and exercises the policy-gradient update.
td.data.model.wOut[0]=0.35;td.data.pending[0].pred=-0.5;
game.move('e7e5');td.resolveLastPetMove(game);
assert(td.data.pending[0].r===1&&td.data.model.steps===1&&td.data.model.policySteps===1,'TD feedback did not train value and policy heads.');
assert(td.data.replay.length===1&&td.data.replay[0].f===td.simplifyFen(beforeFen),'Resolved experience was not stored compactly as FEN + move.');

td.replayLearn();
assert(td.data.model.episodes===1&&td.data.model.steps>1&&td.data.model.policySteps>1,'Experience replay did not train both heads.');

// Self-play is practice, never a rated result or public ranking shortcut.
const practice=new Brain('practice',{persist:false});const pgame=new Chess();
for(const [side,uci] of [['w','e2e4'],['b','e7e5'],['w','g1f3'],['b','b8c6']]){
  const fen=pgame.fen(),move=pgame.move(uci);if(practice.data.pending.some(item=>!item.r))practice.resolveLastPetMove(pgame);
  practice.observePetMove(fen,move.uci,{piece:move.piece,side},pgame.historyMoves().length,pgame);
}
practice.reinforce('practice',pgame);
assert(practice.data.practiceGames===1,'Practice game counter failed.');
assert(practice.data.wins===0&&practice.data.losses===0&&practice.data.draws===0,'Self-play must not alter trainer match record.');
assert(practice.data.elo===100,'V5 must not award legacy Elo.');

// 50 KiB Free and 500 KiB Pro use the same network and same search configuration.
const free=new Brain('free',{persist:false});
const pro=new Brain('pro',{persist:false,plan:'pro'});
assert(free.limit===51200&&pro.limit===512000,'Wrong Free/Pro storage budgets.');
assert(free.data.model.w1.length===pro.data.model.w1.length&&free.data.model.pFrom.length===pro.data.model.pFrom.length,'Pro must not receive a larger neural model.');
assert(!/maxDepth\s*=\s*[^;]*this\.plan/.test(fs.readFileSync(path.join(__dirname,'..','src/soul/brain.js'),'utf8')),'Search depth must not depend on plan.');
assert(free.size()<=free.limit&&pro.size()<=pro.limit,'Fresh brain storage exceeds plan budget.');

// Quantized Soul export/import retains predictions and both learned heads.
const soul=JSON.parse(pet.exportSoul());
assert(soul.version===13&&soul.pet.v===13&&soul.encoding==='residual-48-wdl-bilinear-policy-int4-packed-fen-json-v13','V6 Soul v13 metadata missing.');
assert(soul.pet.n.mv===8&&Array.isArray(soul.pet.n.h2)&&typeof soul.pet.n.h2[1]==='string','Soul v13 did not encode its residual layer.');
const restored=new Brain('restore',{persist:false});restored.importSoul(soul);
assert(Math.abs(restored.predict(x)-pet.predict(x))<0.025,'Mixed-precision Soul quantization changed the value prediction too much.');
const beforeWDL=pet.predictWDL(x),afterWDL=restored.predictWDL(x);assert(Math.abs(beforeWDL.win-afterWDL.win)<0.025&&Math.abs(beforeWDL.draw-afterWDL.draw)<0.025&&Math.abs(beforeWDL.loss-afterWDL.loss)<0.025,'Soul did not preserve WDL output probabilities.');
const policySoul=JSON.parse(policyPet.exportSoul()),policyRestored=new Brain('policy_restore',{persist:false});policyRestored.importSoul(policySoul);
assert(Math.abs(policyRestored.policyProbability(startFeatures,'e2e4','w')-policyPet.policyProbability(startFeatures,'e2e4','w'))<0.025,'Soul did not preserve policy predictions.');
assert(soul.pet.n.mv===8&&Array.isArray(soul.pet.n.a[0])&&typeof soul.pet.n.a[1]==='string'&&Array.isArray(soul.pet.n.e[0])&&typeof soul.pet.n.e[1]==='string','Soul v13 did not use per-channel Int4 trunk and policy weights.');
assert(Array.isArray(soul.pet.n.fr)&&Array.isArray(soul.pet.n.tr)&&Array.isArray(soul.pet.n.sr),'Soul v13 did not preserve low-rank move-interaction weights.');
assert(Buffer.from(soul.pet.n.a[1],'base64').length===Math.ceil(784*48/2),'Trunk Int4 payload length is incorrect.');
assert(Buffer.from(soul.pet.n.e[1],'base64').length===Math.ceil(64*48/2),'Policy Int4 payload length is incorrect.');
assert(restored.size()<=restored.limit,'Restored Free Soul exceeds 50 KiB.');


// V12 Souls pack canonical position keys and reference replay/pending experiences to canonical position-memory
// rows. This avoids repeating long FEN/UCI strings while retaining V5 import.
const tdSoul=JSON.parse(td.exportSoul());
assert(tdSoul.pet.v===13,'TD pet did not export as V6 Soul v13.');
assert(tdSoul.pet.m.length>0&&tdSoul.pet.m[0][0].startsWith('~'),'Soul v13 did not pack canonical FEN position keys.');
assert(tdSoul.pet.r.length===1&&tdSoul.pet.r[0][0]>=0&&tdSoul.pet.r[0][1]>=0,'V13 replay did not reference canonical position memory.');
assert(tdSoul.pet.u.length===1&&tdSoul.pet.u[0][0]>=0&&tdSoul.pet.u[0][1]>=0,'V13 pending experience did not reference canonical position memory.');
const tdRestored=new Brain('td_restore',{persist:false});tdRestored.importSoul(tdSoul);
assert(tdRestored.data.replay.length===td.data.replay.length&&tdRestored.data.replay[0].f===td.data.replay[0].f&&tdRestored.data.replay[0].m===td.data.replay[0].m,'V13 compact replay/FEN reference failed to restore.');
assert(tdRestored.data.pending.length===td.data.pending.length&&tdRestored.data.pending[0].f===td.data.pending[0].f&&tdRestored.data.pending[0].m===td.data.pending[0].m,'V13 compact pending reference failed to restore.');
assert(tdRestored.expandData(tdSoul.pet).updatedAt===td.data.updatedAt,'V13 Soul did not preserve its update timestamp during decoding.');

// Packed-FEN decoder must preserve en-passant squares on both legal target ranks.
for(const epFen of [
  'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3',
  'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6',
  'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq a3',
  'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq h6'
]){
  const fenKey=epFen,source=new Brain('ep_source',{persist:false});source.entry(fenKey,'a2a3').visits=1;
  const migrated=new Brain('ep_restore',{persist:false});migrated.importSoul(JSON.parse(source.exportSoul()));
  assert(migrated.data.memory[fenKey],'Packed-FEN Soul lost an en-passant target or decoded it incorrectly: '+epFen);
}

// Recreate a raw-FEN v11 payload, then build authentic V5/V6 fixtures from it.
// All historical versions must still import into the current 48-wide model.
const expandedForV11=td.expandData(tdSoul.pet);
const legacyV11=JSON.parse(JSON.stringify(tdSoul.pet));legacyV11.v=11;
const packLegacyMap=(map,kind)=>Object.entries(map||{}).map(([fen,moves])=>[fen,Object.entries(moves||{}).map(([move,value])=>kind==='memory'?[move,value.score||0,value.visits||0,value.mirror||0,value.outcomes||0,value.last||0,value.tactical||0]:kind==='opening'?[move,value.count||0,value.last||0]:[move,value.count||0,value.score||0,value.last||0])]);
legacyV11.m=packLegacyMap(expandedForV11.memory,'memory');legacyV11.o=packLegacyMap(expandedForV11.humanOpenings,'opening');legacyV11.n.mv=7;delete legacyV11.n.h2;delete legacyV11.n.b2;
const v11Restored=new Brain('v11_restore',{persist:false});v11Restored.importSoul({format:'Chessling Soul',version:11,encoding:'mixed-int4-trunk-int8-wdl-int4-policy-bilinear-json-v11',pet:legacyV11});
assert(v11Restored.data.memory[td.data.replay[0].f]&&v11Restored.data.replay.length===td.data.replay.length,'V11 raw-FEN compatibility import failed.');
const legacyV12=JSON.parse(JSON.stringify(tdSoul.pet));legacyV12.v=12;legacyV12.n.mv=7;delete legacyV12.n.h2;delete legacyV12.n.b2;
const v12Restored=new Brain('v12_restore',{persist:false});v12Restored.importSoul({format:'Chessling Soul',version:12,encoding:'mixed-int4-trunk-int8-wdl-int4-policy-bilinear-packed-fen-json-v12',pet:legacyV12});
assert(v12Restored.data.model.w2.every(value=>value===0)&&v12Restored.data.replay.length===td.data.replay.length,'V12 packed-FEN Soul did not warm-start into the zero-initialised V13 residual model.');
const legacyV5=JSON.parse(JSON.stringify(legacyV11));legacyV5.v=5;
const oldBrain=new Brain('legacy_source',{persist:false,seed:31415}),oldModel=oldBrain.data.model;
const packLegacy=(values)=>{let max=Math.max(0,...values.map(v=>Math.abs(v))),scale=max?max/127:1/127;const bytes=values.map(v=>{let q=Math.max(-127,Math.min(127,Math.round(v/scale)));return q<0?q+256:q;});let out='';for(let i=0;i<bytes.length;i+=3){const a=bytes[i],hb=i+1<bytes.length,hc=i+2<bytes.length,b=hb?bytes[i+1]:0,c=hc?bytes[i+2]:0,chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';out+=chars[a>>2]+chars[((a&3)<<4)|(b>>4)]+(hb?chars[((b&15)<<2)|(c>>6)]:'=')+(hc?chars[c&63]:'=');}return [Number(scale.toPrecision(8)),out];};
const project=(values,rows,from,to)=>Array.from({length:rows*to},(_,i)=>values[Math.floor(i/to)*from+(i%to)]||0);
const pack4=(arr,channels)=>{const scales=Array(channels).fill(0);for(let i=0;i<arr.length;i++)scales[i%channels]=Math.max(scales[i%channels],Math.abs(arr[i]));for(let i=0;i<channels;i++)scales[i]=scales[i]?scales[i]/7:1/7;const bytes=new Uint8Array(Math.ceil(arr.length/2));for(let i=0;i<arr.length;i++){const q=Math.max(-7,Math.min(7,Math.round(arr[i]/scales[i%channels]))),n=q<0?q+16:q;if(i&1)bytes[i>>1]|=n<<4;else bytes[i>>1]=n;}return [scales,Buffer.from(bytes).toString('base64'),arr.length];};
legacyV5.n={mv:2,a:packLegacy(project(oldModel.w1,784,48,16)),b:packLegacy(oldModel.b1.slice(0,16)),c:packLegacy(Array(16).fill(0.01)),d:0,e:packLegacy(project(oldModel.pFrom,64,48,16)),f:packLegacy(project(oldModel.pTo,64,48,16)),g:packLegacy(project(oldModel.pPiece,6,48,16)),h:packLegacy(project(oldModel.pPromo,5,48,16)),j:packLegacy(oldModel.pFromBias),k:packLegacy(oldModel.pToBias),u:packLegacy(oldModel.pPieceBias),v:packLegacy(oldModel.pPromoBias),s:0,p:0,x:0,l:0,z:0};
legacyV5.r=td.data.replay.map(item=>[item.f,item.m,item.y,item.n,item.p,item.side==='b'?1:0]);legacyV5.u=td.data.pending.map(item=>[item.f,item.m,item.r?1:0,item.ply,item.side,item.at,item.pred]);legacyV5.q=[];
const v5Bytes=Buffer.byteLength(JSON.stringify({r:legacyV5.r,u:legacyV5.u})),v11Bytes=Buffer.byteLength(JSON.stringify({r:tdSoul.pet.r,u:tdSoul.pet.u}));
assert(v11Bytes<v5Bytes,`Position-reference encoding did not reduce FEN/UCI payload (${v11Bytes} vs ${v5Bytes}).`);
const v5Restored=new Brain('v5_restore',{persist:false});v5Restored.importSoul({format:'Chessling Soul',version:5,encoding:'compact-int8-neural-json-v5',pet:legacyV5});
assert(v5Restored.data.replay[0].f===td.data.replay[0].f&&v5Restored.data.pending[0].m===td.data.pending[0].m,'V5 legacy replay/pending migration failed.');
assert(v5Restored.data.model.w1.length===784*48&&v5Restored.data.model.steps===0,'V5 model migration did not expand the trunk safely or reset incompatible counters.');
const legacyV6=JSON.parse(JSON.stringify(legacyV5));legacyV6.v=6;
legacyV6.r=td.data.replay.map(item=>{const row=legacyV6.m.findIndex(entry=>entry[0]===item.f),mi=legacyV6.m[row]?.[1]?.findIndex(entry=>entry[0]===item.m)??-1;return [row,mi,item.y,item.n,item.p,item.side==='b'?1:0];});
legacyV6.u=td.data.pending.map(item=>{const row=legacyV6.m.findIndex(entry=>entry[0]===item.f),mi=legacyV6.m[row]?.[1]?.findIndex(entry=>entry[0]===item.m)??-1;return [row,mi,item.r?1:0,item.ply,item.side,item.at,item.pred];});
const v6Restored=new Brain('v6_restore',{persist:false});v6Restored.importSoul({format:'Chessling Soul',version:6,encoding:'compact-int8-neural-json-v6',pet:legacyV6});
assert(v6Restored.data.model.w1.length===784*48&&v6Restored.data.replay.length===td.data.replay.length,'V6 scalar Soul did not migrate to V13 WDL residual model with replay intact.');

const currentM=td.data.model;
const to24=key=>project(currentM[key],({w1:784,wOut:3,pFrom:64,pTo:64,pPiece:6,pPromo:5})[key],48,24);
const to40=key=>project(currentM[key],({w1:784,wOut:3,pFrom:64,pTo:64,pPiece:6,pPromo:5})[key],48,40);
const state24=project(currentM.pStateRank,24,48,24),state40=project(currentM.pStateRank,40,48,40);
const v7Clone=JSON.parse(JSON.stringify(legacyV11));v7Clone.v=7;v7Clone.n.mv=3;delete v7Clone.n.fr;delete v7Clone.n.tr;delete v7Clone.n.sr;
v7Clone.n.a=packLegacy(to24('w1'));v7Clone.n.b=packLegacy(currentM.b1.slice(0,24));v7Clone.n.c=packLegacy(to24('wOut'));
v7Clone.n.e=packLegacy(to24('pFrom'));v7Clone.n.f=packLegacy(to24('pTo'));v7Clone.n.g=packLegacy(to24('pPiece'));v7Clone.n.h=packLegacy(to24('pPromo'));
for(const key of ['pFromBias','pToBias','pPieceBias','pPromoBias'])v7Clone.n[{pFromBias:'j',pToBias:'k',pPieceBias:'u',pPromoBias:'v'}[key]]=packLegacy(currentM[key]);
const v7Restored=new Brain('v7_restore',{persist:false});v7Restored.importSoul({format:'Chessling Soul',version:7,encoding:'compact-int8-neural-json-v7',pet:v7Clone});
assert(v7Restored.data.model.w1.length===784*48&&v7Restored.data.model.wOut.length===144,'V7 WDL Soul did not warm-start into V13.');
const v8Clone=JSON.parse(JSON.stringify(v7Clone));v8Clone.v=8;v8Clone.n.mv=4;
v8Clone.n.e=pack4(to24('pFrom'),24);v8Clone.n.f=pack4(to24('pTo'),24);v8Clone.n.g=pack4(to24('pPiece'),24);v8Clone.n.h=pack4(to24('pPromo'),24);
const v8Restored=new Brain('v8_restore',{persist:false});v8Restored.importSoul({format:'Chessling Soul',version:8,encoding:'mixed-int8-int4-neural-json-v8',pet:v8Clone});
assert(v8Restored.data.model.pFromRank.length===64*4&&v8Restored.data.replay.length===td.data.replay.length,'V8 Soul failed to initialise bilinear interactions or preserve replay.');
const v9Clone=JSON.parse(JSON.stringify(v8Clone));v9Clone.v=9;v9Clone.n.mv=5;
v9Clone.n.fr=soul.pet.n.fr;v9Clone.n.tr=soul.pet.n.tr;v9Clone.n.sr=pack4(state24,24);
const v9Restored=new Brain('v9_restore',{persist:false});v9Restored.importSoul({format:'Chessling Soul',version:9,encoding:'mixed-int8-int4-bilinear-policy-json-v9',pet:v9Clone});
assert(v9Restored.data.model.w1.length===784*48&&v9Restored.data.replay.length===td.data.replay.length,'V9 model failed to warm-start into V13.');
const v10Clone=JSON.parse(JSON.stringify(legacyV11));v10Clone.v=10;v10Clone.n.mv=6;
v10Clone.n.a=pack4(to40('w1'),40);v10Clone.n.b=packLegacy(currentM.b1.slice(0,40));v10Clone.n.c=packLegacy(to40('wOut'));
v10Clone.n.e=pack4(to40('pFrom'),40);v10Clone.n.f=pack4(to40('pTo'),40);v10Clone.n.g=pack4(to40('pPiece'),40);v10Clone.n.h=pack4(to40('pPromo'),40);v10Clone.n.sr=pack4(state40,40);
const v10Restored=new Brain('v10_restore',{persist:false});v10Restored.importSoul({format:'Chessling Soul',version:10,encoding:'mixed-int4-trunk-int8-wdl-int4-policy-bilinear-json-v10',pet:v10Clone});
assert(v10Restored.data.model.w1.length===784*48&&v10Restored.data.model.wOut.length===144,'V10 40-wide Soul did not migrate into V13.');

// The replay policy must calculate actor advantage before the value update;
// this checks that an extreme value correction cannot erase the policy signal.
const replayBrain=new Brain('replay_advantage',{persist:false,seed:707});
const replayFen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -';
const replayMoves=new Chess(replayFen).moves({verbose:true,skipSan:true}).map(m=>m.uci);
replayBrain.addReplay(replayFen,replayMoves[0],0.9,1.5,'w');
const beforeReplayPolicy=replayBrain.data.model.policySteps;replayBrain.replayLearn();
assert(replayBrain.data.model.policySteps>beforeReplayPolicy,'Replay did not train the policy head from its pre-update advantage.');

// Rare tactical memories receive retention utility and are not automatically
// treated as disposable merely because they have few visits.
const memoryBrain=new Brain('memory_utility',{persist:false,seed:708});
const oldStamp=Date.now()-365*24*60*60*1000;
memoryBrain.data.memory['ordinary-old-position w - -']={e2e4:{score:0,visits:1,outcomes:0,last:oldStamp,tactical:0}};
memoryBrain.data.memory['rare-tactical-position w - -']={g6h7:{score:3,visits:1,outcomes:1,last:oldStamp,tactical:5}};
assert(memoryBrain.memoryUtility(memoryBrain.data.memory['rare-tactical-position w - -'])>memoryBrain.memoryUtility(memoryBrain.data.memory['ordinary-old-position w - -']),'Rare tactical memory did not receive a protection bonus.');
for(let i=0;i<900;i++)memoryBrain.data.memory[`ordinary-pressure-${String(i).padStart(4,'0')}-${'x'.repeat(38)} w - -`]={e2e4:{score:0,visits:1,outcomes:0,last:oldStamp,tactical:0}};
memoryBrain.pruneToBudget();
assert(memoryBrain.size()<=memoryBrain.limit,'Budget pruning failed to restore the Free brain cap.');
assert(memoryBrain.data.memory['rare-tactical-position w - -']?.g6h7?.tactical===5,'Budget pruning discarded a rare tactical memory before ordinary low-utility positions.');
assert(Object.keys(memoryBrain.data.memory).length>0,'Budget pruning wiped the entire memory table.');
const retainedCount=Object.keys(memoryBrain.data.memory).length;
memoryBrain.pruneForStoragePressure();
assert(memoryBrain.data.memory['rare-tactical-position w - -']?.g6h7?.tactical===5&&Object.keys(memoryBrain.data.memory).length>0,'Storage-pressure fallback erased protected learning history.');


// Stress the encoding with full Free-sized replay/pending tables. The repeated
// strings should be stored once in memory, then addressed by small indexes.
const compressionFixture=new Brain('compression_fixture',{persist:false});
for(let i=0;i<160;i++){
  const fen=`synthetic-position-${String(i).padStart(3,'0')} w - -`;
  compressionFixture.data.memory[fen]={e2e4:{score:i%20,visits:3,mirror:0,outcomes:1,last:i+1}};
  compressionFixture.data.replay.push({f:fen,m:'e2e4',y:(i%3-1)*50,n:2,p:25,side:'w'});
  if(i<120)compressionFixture.data.pending.push({f:fen,m:'e2e4',x:null,r:i%2,ply:i+1,side:'w',at:i+100,pred:0.1});
}
const stressV6=compressionFixture.compactData();
const stressV5=JSON.parse(JSON.stringify(stressV6));
stressV5.v=5;
stressV5.r=compressionFixture.data.replay.map(item=>[item.f,item.m,item.y,item.n,item.p,item.side==='b'?1:0]);
stressV5.u=compressionFixture.data.pending.map(item=>[item.f,item.m,item.r?1:0,item.ply,item.side,item.at,item.pred]);
stressV5.q=[];
const stressV5Bytes=Buffer.byteLength(JSON.stringify({r:stressV5.r,u:stressV5.u}));
const stressV6Bytes=Buffer.byteLength(JSON.stringify({r:stressV6.r,u:stressV6.u}));
assert(stressV6Bytes<stressV5Bytes*0.82,`Full replay/pending table compression was too small (${stressV6Bytes} vs ${stressV5Bytes}).`);

// V4 compact Souls migrate safely: memories remain, incompatible old weights are not misrepresented as V5.
const oldFen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -';
const v4={format:'Chessling Soul',version:4,pet:{v:4,i:['OlderPet','older_pet','Trainer',2,130,1000,1,0,0,1,0],w:[100,110,110,120,130,9000],a:[0,0,0,0],t:[60,50,50],n:{w:Array(288).fill(0.01),b:Array(12).fill(0),o:Array(12).fill(0),z:0,s:10,e:1,l:0.1,d:0},r:[],m:[[oldFen,[['e2e4',12,3,0,1,1]]]],h:[[oldFen,[['e2e4',2,1]]]],o:[],q:[],g:[0,0,0,0,0],l:null,c:1,u:2}};
const migrated=new Brain('migrate',{persist:false});migrated.importSoul(v4);
assert(migrated.data.petName==='OlderPet'&&migrated.data.model.w1.length===784*48,'V4 did not migrate to the current V13 research architecture.');
assert(migrated.data.memory[oldFen]?.e2e4?.score===12,'V4 episodic position memory was not preserved.');
assert(migrated.data.model.steps===0,"V4's incompatible feature weights must not be falsely reported as V5-trained weights.");

// Pro capacity retains substantially more individual memories without enlarging the model.
for(let i=0;i<1500;i++){
  const key=`synthetic-position-${i} w - -`;
  pro.data.memory[key]={e2e4:{score:i%90,visits:4,mirror:0,outcomes:2,last:i+1}};
}
pro.save();
assert(pro.memoryCount()>1000&&pro.memoryCount()>free.memoryCount(),"Pro should retain beyond Free's 1,000-position ceiling when bytes allow.");
assert(pro.size()<=512000,'Pro brain exceeded its 500 KiB hard cap.');
const downgraded=new Brain('downgraded',{persist:false,data:pro.compactData(),plan:'free'});
assert(downgraded.size()<=51200,'A Pro brain loaded on Free must be pruned to the Free hard cap immediately.');

console.log('Chelo research neural-learning tests passed.');
console.log(`Value model: ${predicted.toFixed(3)} after 1,200 updates; learned policy priors e4=${e4prior.toFixed(3)} d4=${d4prior.toFixed(3)}.`);
console.log(`Storage: Free ${free.size()} / 51,200 bytes; Pro ${pro.size()} / 512,000 bytes; model weights identical in shape.`);
console.log(`Soul v13 single-game fixture: ${v5Bytes} → ${v11Bytes} bytes; full-table fixture: ${stressV5Bytes} → ${stressV6Bytes} bytes (${(100*(1-stressV6Bytes/stressV5Bytes)).toFixed(1)}% smaller).`);
console.log('TD/WDL learning, factorised + low-rank policy, Int4 Soul, replay, storage retention, owner non-copying, practice anti-rating and V4–V12 Soul migrations, residual-layer preservation and packed-FEN round trips (including en-passant targets) passed.');
