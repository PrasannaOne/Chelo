#!/bin/sh
set -eu
node tests/worker.test.js
node workers/arena/tests/worker.test.mjs
python3 tests/arena_schema.test.py
