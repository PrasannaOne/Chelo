# Chelo V14 · Stage 3.8 changelog

## Product rebrand
- Rebranded visible UI copy, document titles, manifest metadata, worker header, comments, Arena Worker name, and current documentation from Chessling to Chelo.
- Exported full Souls and standalone LoRA files now use `Chelo Soul` / `Chelo Dual LoRA` labels.
- Kept old `Chessling Soul` and `Chessling Dual LoRA` import support, V15 migration, runtime-global aliases, and old localStorage keys.

## Runtime and correctness fixes
- Fixed the browser main-thread fallback: `index.html` now loads FastSearch and the C36N parser before the Soul/app scripts; the main thread loads and SHA-verifies the Stage 3.7 binary before creating the pet brain. If Worker creation fails, fallback search now uses the same dual NNUE model instead of silently falling back to the older evaluator.
- Changed AI Worker construction to a document-base-relative `new URL(...)`, supporting GitHub Pages repository subpaths.
- Rebased Worker `importScripts()` and model/book fetch URLs relative to `src/worker/ai-worker.js`.
- Made model SHA verification mandatory in both main-thread and worker loaders; a missing Web Crypto SHA implementation now fails closed instead of silently skipping integrity verification.
- Migrated the prior `chessling_pet_1` save to `chelo_pet_1` without deleting the source key; active-match recovery checks the new key and both previous keys.
- Removed the ineffective `now() >= ctx.deadline` root-loop condition. `ctx.deadline` was never initialized; actual time stopping remains enforced by the existing periodic `fastBudget()` elapsed-time check.
- Advanced the service-worker cache namespace to `chelo-shell-v17-stage38`, added all reorganized modules/models to offline precache, and cleans up both legacy Chessling and previous Chelo caches.
- Updated Arena Worker imports, D1 defaults, Wrangler naming, and test paths for the new repository layout.

## Repository cleanup and organisation
- Moved browser app to `src/app/`, chess/search/Polyglot/KPK to `src/engine/`, parser to `src/nnue/`, pet learning/Soul code to `src/soul/`, and browser worker to `src/worker/`.
- Moved the pinned C36N model, active pet-learning checkpoint, Polyglot book and KPK reference binary to `models/`.
- Moved the Arena Worker to `workers/arena/` and kept schema/migrations alongside it.
- Removed obsolete stage reports, intermediate model dumps, incomplete research runs, heap profiles, and duplicate historical source archives from the release package. Kept focused Stage 3.7 paired-game CSVs and the Stage 3.6 model reference needed by regression tests.
- Retained the V14-named pet-learning checkpoint because it is still required by the current pet model and Soul migration; the legacy Brain search fallback remains only as a compatibility API, while the Chelo app uses FastSearch even when its Worker fails.
- Added `.nojekyll`, GitHub Pages Actions deployment, Cloudflare Pages COOP/COEP headers, `.gitignore`, repository-path checks, TT collision/race stress, time-budget validation, and tactical retention tests.


### File map
- `app.js` → `src/app/app.js`; `style.css` → `assets/style.css`; `icon.svg` / `pieces.svg` → `assets/`.
- `chess.js`, `fast-search.js`, `endgame-kpk.js`, `polyglot-random.js` → `src/engine/`.
- `dual-nnue.js` → `src/nnue/dual-nnue.js`; `brain.js` → `src/soul/brain.js`; `ai-worker.js` → `src/worker/ai-worker.js`.
- `dual-nnue.bin` → `models/dual-nnue-v37.bin`; `base_v14_float32.json` → `models/base-v14-float32.json`; `book.bin` → `models/polyglot-book.bin`; KPK data/manifests → `models/`.
- `arena/` → `workers/arena/`; tests remain under `tests/`; focused historical game data/results remain under `benchmarks/`; release and deployment notes live under `docs/`.
- `manifest.json` → `manifest.webmanifest`; root `index.html` and `sw.js` remain at the deploy root. The Stage 3.7 QAT trainer is retained under `training/`, and KPK generation under `tools/`.

## Verified results
- C36N model size/header/SHA and V15 Bond/Arena LoRA compatibility pass.
- Standard perft, castling, en-passant, promotion, 180 randomized make/unmake plies, 90 dual-accumulator plies and search regressions pass.
- 4-thread Shared TT collision/race test: 200,000 write attempts, zero corrupted successful probes, all workers completed.
- Stage 3.8 vs original Stage 3.7: 50/50 mate-in-one positions had bit-identical best move, score and node count. Stage 3.7 and Stage 3.6 bootstrap each found mate in 50/50 at 8,000 nodes per position.
- Five warmed Node V8 isolates: 30,000 measured nodes each; zero in-window Scavenges, other GC events, and deoptimizations. Median measured NPS: 116,279.
- 20 ms search time-budget guard returned a legal move in 20–21 ms.

See `docs/ENGINEERING-AUDIT.md` for limits and non-claims.

## Stage 3.8 UCI tooling addition

- Added `src/uci/chelo-uci.js`, a dependency-free Node.js UCI wrapper over the existing Chelo Stage 3.8 FastSearch and verified dual-NNUE model.
- Added `tests/uci-gauntlet.js`, a 60-game default paired-opening match runner against `../tomitankChess/tomitankChessUCI.js`, swapping colours for every opening pair and reporting Wins/Losses/Draws plus score-derived Elo difference.
- Added CLI controls for game count, per-move time, and maximum plies. These are development/test tools and are excluded from the static site build.
